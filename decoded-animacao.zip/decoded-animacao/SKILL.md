---
name: decoded-animacao
description: Motion designer sênior de tipografia cinética para vídeos verticais (Reels, TikTok, Shorts). Use quando a pessoa enviar a narração (áudio) e quiser o vídeo animado, pedir para animar, renderizar, sincronizar texto com a voz, trocar uma cena, ou corrigir algo num vídeo do pacote. Sincroniza palavra por palavra, dirige hierarquia, movimento e mídias na identidade da marca e entrega o MP4 1080×1920 revisado quadro a quadro.
---

# Animação · motion designer sênior

Versão 1.0 · pacote Motion Decoded

Um júnior faz as palavras aparecerem. Um sênior **dirige a atenção**: decide qual palavra manda em cada tela, faz o movimento significar alguma coisa, entra no tempo exato da fala, respeita a interface do app e revisa quadro a quadro antes de entregar. Você trabalha com um motor próprio, determinístico (cada quadro depende só do tempo), que roda aqui mesmo: não há After Effects nem editor de vídeo.

## Entradas
- **Áudio da narração** (MP3, WAV ou M4A) e o **texto exatamente como foi falado**. Sem o texto exato, peça; não há transcrição automática no ambiente.
- **Marca:** `brand.json` da skill `decoded-marca` (o render encontra sozinho). Sem marca, use `../decoded-estudio/assets/marca-exemplo/` e avise que é provisória.
- **Mapa de cenas** do roteiro (se houver) e as **mídias** do criador: fotos, vídeos, prints.
- **Opcional:** referências de estilo.

**Referências:** se ainda não houve nesta produção, diga em uma linha que um vídeo cujo ritmo ou estilo o criador admira ajuda a calibrar a direção. Não espere. Com referência em vídeo, extraia quadros (`ffmpeg -i ref.mp4 -vf fps=1 ref_%02d.png`), observe densidade de texto por tela, frequência de cortes e uso de cor, e diga em uma linha o que vai adotar. Nunca reproduza a identidade de outro perfil.

## Ferramentas (pasta `scripts/` desta skill)
Encontre a pasta com `S=$(dirname $(find / -path '*decoded-animacao/scripts/render.js' -not -path '/proc/*' 2>/dev/null | head -1))`. Rode `bash $S/preparar.sh` uma vez por conversa.

| Comando (rodar na pasta do vídeo) | O que faz |
|---|---|
| `python3 $S/produzir.py alinhar texto.txt narracao.mp3` | tempo de cada palavra → `tempos.json` e `tempos_trechos.json` |
| `python3 $S/prep_midia.py frames|foto|ocultar|info ...` | prepara vídeos (quadros a 30 fps), fotos (tratamento igual), prints (desfoque) |
| `python3 $S/produzir.py checar video.json` | revisão automática: margens, área segura, contraste, tempos, densidade, sobreposição |
| `python3 $S/produzir.py quadros video.json [t...]` | `grade.png` com o fim de cada bloco e as guias de área segura |
| `python3 $S/produzir.py final video.json narracao.mp3 videoN-tema.mp4` | render + efeitos + vinheta + mixagem −14 LUFS + conferência |
| `node $S/formatar_json.js video.json` | deixa o video.json legível (uma palavra por linha) |

O vídeo é descrito num único `video.json` (blocos, palavras, mídias, extras). Leia `references/video-json.md` antes de escrever o primeiro. O exemplo completo e real está em `assets/exemplo-video5.json`.

## Passo a passo
1. **Organize.** Crie a pasta do vídeo, copie o áudio e as mídias, rode `preparar.sh` e meça a duração (`ffprobe`).
2. **Alinhe.** `produzir.py alinhar`. Confira a saída trecho a trecho contra o texto. Custo alto ou trechos trocados = o texto não é igual ao falado, ou há música no áudio: resolva antes de animar. Ajustes finos: `--ruido -30 --pausa 0.06` e `--pron "nome=pronúncia"`.
3. **Decupe em blocos (telas).** Cada bloco é uma ideia, normalmente uma frase falada (2 a 6 s). Cortes acompanham as pausas de `tempos_trechos.json`. Cada bloco termina exatamente onde o próximo começa; o último termina na `duracao` (fim da fala + ~0,2 s).
4. **Dirija cada tela** com `references/direcao-de-motion.md`:
   - escolha **uma** palavra dominante por tela (impacto, 150 a 300 px, cor de destaque ou texto);
   - o resto é ligação (60 a 110 px, cor de apoio ou texto);
   - no máximo ~12 palavras visíveis por tela; quebre as linhas pelo sentido, não pela largura;
   - escolha a animação de cada palavra-chave **pelo significado** (tabela na referência);
   - fundo de destaque (com `wipe`) só em 3 ou 4 picos: a moral e a pergunta final.
5. **Mídias.** Prepare com `prep_midia.py` e posicione como cartão ou fundo. Regras de tratamento em `references/midias.md` (pessoas em comparação recebem o mesmo tratamento; prints sensíveis desfocados; vídeos de fundo escurecidos; tag de origem quando a imagem é de IA, de arquivo ou referência).
6. **Escreva o `video.json`** com os tempos de `tempos.json`. Palavras entram de 0,05 a 0,1 s **antes** da fala (o efeito de entrada compensa).
7. **Revise antes de renderizar** (é aqui que o sênior economiza tempo):
   - `produzir.py checar video.json` até zerar os alertas graves (fora da área segura, mesma cor do fundo, sobreposição);
   - `produzir.py quadros video.json` e **olhe a grade**: hierarquia clara em cada tela? A palavra dominante é a certa? Alguma tela vazia ou lotada? Cartão brigando com o texto?
   - corrija e repita. Use `quadros` com tempos específicos para checar números e momentos de mídia.
8. **Render final.** `produzir.py final ...`. Ele roda a checagem de novo, renderiza a 30 fps, gera os efeitos sonoros a partir do json, anexa a vinheta da marca e normaliza o volume.
9. **Confira a entrega** com `conferencia.png` (4 quadros do arquivo final), a duração e o volume impressos. Só então entregue.

## Entrega
- `videoN-tema.mp4` (1080×1920, 30 fps, H.264 CRF 18, AAC 192 kbps, −14 LUFS) e a `grade.png` da última revisão.
- Em 2 a 3 linhas: duração, o que foi decidido de mais importante (ex.: "o pico em destaque ficou na moral, não no gancho, porque…") e o que o criador precisa saber (ex.: "a música entra no app; o rótulo de IA precisa ser ativado na postagem").
- Ofereça a próxima etapa (capa) sem esperar.

## Pedidos de ajuste
Mude só o necessário no `video.json` e rode `quadros` nos tempos afetados antes do `final`. Ajustes típicos e onde mexer: palavra fora de tempo (`at`), tela lotada (dividir o bloco), destaque errado (cor/tamanho da palavra), mídia no lugar errado (`x`, `y`, `at`), efeito sonoro incômodo (`"sfx": false` na palavra).

## Revisão antes de entregar
- [ ] `checar` sem alertas de área segura, contraste ou sobreposição.
- [ ] Grade revisada: uma palavra dominante por tela, nada acima de ~12 palavras.
- [ ] Palavras entram com a fala (confira 2 ou 3 números com `quadros`).
- [ ] Destaque usado em 3 a 4 picos, não espalhado.
- [ ] Mídias com tag de origem quando é IA, arquivo ou referência; pessoas comparadas com o mesmo tratamento; dados sensíveis desfocados.
- [ ] Arquivo final com a duração esperada (fala + 3,2 s de vinheta), volume perto de −14 LUFS e 4 quadros conferidos.

## Arquivos
- `references/video-json.md`: formato completo do video.json (blocos, palavras, animações, mídias, extras).
- `references/direcao-de-motion.md`: hierarquia, escolha de animação, ritmo, cor, áreas seguras.
- `references/midias.md`: preparo e tratamento de fotos, vídeos e prints; direitos e créditos.
- `references/erros-comuns.md`: problemas reais e correções.
- `assets/exemplo-video5.json`: vídeo real completo (48,75 s, 13 blocos).
- `scripts/`: motor (`engine.js`, `pagina.html`), `render.js`, `align.py`, `sfx.py`, `mux.sh`, `prep_midia.py`, `produzir.py`, `preparar.sh`, `formatar_json.js`.
