# video.json · formato completo

```json
{
 "tema": "Luxo · feito à mão",          // aparece à direita no cabeçalho
 "serie": "DECODIFICADO",               // à esquerda no cabeçalho (padrão: primeira série da marca)
 "duracao": 48.75,                      // fim da fala + ~0,2 s (sem a vinheta)
 "cabecalho": {"barra": true},          // false desliga cabeçalho e barra de progresso
 "assinatura": true,                    // vinheta da marca no fim (3,2 s)
 "sfx": true,                           // efeitos sonoros automáticos
 "blocos": [ ... ]
}
```
Cores sempre **por papel**: `fundo`, `texto`, `destaque`, `apoio`, `rotulo`, `card`, `linha`. Nunca hex.

## Bloco (uma tela)
```json
{"a": 17.72, "b": 22.95, "bg": "fundo", "wipe": true, "cy": 1270, "alinhar": "centro",
 "midias": [...], "extras": [...], "passo": {"n": "01", "rotulo": "O TEMA"},
 "linhas": [ [palavra, palavra], [palavra] ]}
```
| Campo | Notas |
|---|---|
| `a`, `b` | início e fim em segundos. `b` de um bloco = `a` do próximo |
| `bg` | `fundo` (padrão) ou `destaque` (texto em `fundo` por cima) |
| `wipe` | troca de fundo com círculo crescendo de (540, 900); ou `[x, y]` |
| `cy` | centro vertical do texto. 900 a 960 sem mídia; 1250 a 1300 com cartão em cima |
| `alinhar` | `centro` (padrão) ou `esquerda` |
| `passo` | número grande + rótulo no topo (séries de processo) |
| `sem_saida` | `true` mantém o bloco sem o desfoque de saída (raro) |

## Palavra
`["texto", "papel_da_fonte", tamanho_px, "cor", at, "animação", {opções}]`
- `papel_da_fonte`: `impacto` (palavra-chave), `ligacao` (palavras de ligação), `codigo`.
- `at`: segundo em que entra (do `tempos.json`, 0,05 a 0,1 s antes).
- `animação`: padrão `pop` para impacto e `blur` para ligação. Pode ser omitida.
- Várias palavras numa única entrada são permitidas ("à mão.", "NÃO É."), quando a animação deve ser uma só.
- A linha que passar de 900 px é reduzida sozinha (o `checar` avisa quando a redução é grande).

### Animações
| Nome | Efeito | Use para |
|---|---|---|
| `blur` | surge do desfoque | ligação (padrão) |
| `rise` | sobe 70 px | nomes, sequências, listas |
| `pop` | escala com exagero | impacto (padrão) |
| `stamp` | cai de 2,2× | crítica, veredito ("BARATO") |
| `shrink` / `grow` | entra e encolhe / cresce | "menor", "maior", "cai", "sobe" |
| `count` | número contando | valores; opções `{"from":0,"dur":0.55,"suf":"%","pad0":2}` |
| `draw` | contorno desenhado e preenchido | escrita à mão, "minha", "assinado" |
| `glitch` | deslocamento RGB | IA, digital, falso, erro |
| `step` | entra em degraus | "quadro a quadro", "passo a passo" |
| `strike` / `strike2` | risca 1 ou 2 vezes | negação ("sem", "não paga") |
| `mark` | marca-texto atrás | citação, print, frase de alguém |
| `initial` | destaca a 1ª letra | siglas escondidas ("Inteligência Artesanal" → I.A.) |
| `dots` | reticências em bolinhas | suspense ("Mas e aí ...") |
| `type` | digitação com cursor | comandos, buscas, mensagens |
| `none` | sem animação | raro |

Opções comuns: `"sfx": false` (silencia o efeito), `"pad": 40` (espaço extra acima da linha), `"cor_risco": "destaque"`, `"fundo_marca": "texto"`.

## Mídias (`midias` do bloco)
```json
{"tipo": "fundo", "src": "foto.jpg", "escurecer": 0.55, "desfoque": 0, "fade": 0.3}
{"tipo": "fundo", "frames": "pf", "at": 0, "offset": 0, "escurecer": 0.6}
{"tipo": "cartao", "src": "pessoa.jpg", "at": 11.6, "x": 540, "y": 640, "w": 420, "h": 620, "rot": 2,
 "borda": "texto", "tag": {"texto": "ex-animador da Disney", "x": 540, "y": 980, "at": 12.9, "estilo": "destaque"},
 "efeito": {"tipo": "pixelar", "at": 20.2}}
{"tipo": "tag", "texto": "imagem gerada por IA", "x": 770, "y": 355, "at": 30.3, "estilo": "neutro"}
```
- `frames`: pasta gerada por `prep_midia.py frames` (f0001.jpg...). `offset` avança dentro do clipe; `loop: true` repete.
- `borda`: `destaque` = protagonista; `texto`/`rotulo` = neutro.
- `efeito`: `pixelar` (algo "barato", digital) ou `apagar` (perde cor e foco: "para de impressionar").
- Tags: `destaque` (padrão) ou `neutro`. Ficam presas entre x 90 e 990 automaticamente.

## Extras (`extras` do bloco)
| tipo | Campos | Uso |
|---|---|---|
| `checks` | `palavras`, `at` (lista) | ✓ ao lado de palavras |
| `selo` | `texto`, `x`, `y`, `at`, `tamanho`, `estilo: cheio|contorno` | pílula com texto ("I.A. ✍︎", "o INSS continua") |
| `linha_tempo` | `y`, `at`, `pontos` (lista de rótulos) | datas, antes e depois |
| `calendario` | (usa a palavra `count` do bloco) | dia do mês contando. Deixe a linha do número sem nada acima: a moldura ocupa ~340 px sobre ele |
| `metade` | `palavra`, `at` | barra que se divide ("metade") |
| `brilho` | `palavra`, `at` | estrela girando ao lado ("NOVIDADE") |
| `icone` | `nome: rewind|play|seta`, `x`, `y`, `at`, `ate` | ícones simples |
| `codigo` | `texto`, `y`, `at` | linha de código digitada |
| `onda` | `y`, `at`, `ate`, `amps` (opcional) | onda sonora (voz, áudio) |
| `imagem` | `src`, `x`, `y`, `w`, `h`, `at`, `rot` | logo ou objeto recortado (PNG transparente) |

## Exemplo mínimo
```json
{"tema": "13º salário", "serie": "DECODIFICADO", "duracao": 6.2, "blocos": [
 {"a": 0, "b": 3.1, "cy": 900, "linhas": [
   [["Por","ligacao",96,"apoio",0.05],["que","ligacao",96,"apoio",0.2],["a","ligacao",96,"apoio",0.33]],
   [["2ª PARCELA","impacto",170,"destaque",0.45]],
   [["pode","ligacao",96,"texto",1.3],["vir","ligacao",96,"texto",1.5]],
   [["MENOR?","impacto",220,"texto",1.75,"shrink"]]]},
 {"a": 3.1, "b": 6.2, "bg": "destaque", "wipe": true, "cy": 900, "linhas": [
   [["18","impacto",300,"fundo",3.3,"count",{"from":1,"pad0":2}]],
   [["sem","ligacao",90,"fundo",4.4],["desconto","impacto",120,"fundo",4.6,"strike"]]],
  "extras": [{"tipo": "calendario"}]}
]}
```
