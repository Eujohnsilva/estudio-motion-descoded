# Erros reais e correções

| Erro | Correção |
|---|---|
| Texto vazando da tela ("DESVANTAGEM", "ESPONTÂNEO") | o motor reduz linhas acima de 900 px; se a redução passar de 10%, quebre a linha ou diminua a palavra |
| Palavras coladas durante o `pop` | o espaço mínimo é 20% da maior palavra da linha; se ainda colar, separe em duas linhas |
| Elemento na cor do fundo (calendário em destaque sobre fundo destaque) | as cores dos extras herdam a cor da palavra; confira com `checar` |
| Cabeçalho escondido atrás de vídeo de fundo | o cabeçalho é desenhado por último; não use mídia com `y` < 250 |
| Legenda queimada do vídeo original brigando com o texto | fundo com `desfoque` 7 e `escurecer` 0,5 |
| Artefato de 3 quadros na troca para a vinheta | `duracao` no fim da fala + 0,2 s, nunca no meio de um `wipe` |
| Texto do roteiro diferente do falado: tempos tortos | alinhar com o texto da gravação; custo alto no `alinhar` é o sinal |
| Número caindo fora do tempo numa frase longa | `alinhar` com `--ruido -30 --pausa 0.06` e conferir com `quadros` no instante |
| Print com dado sensível visível | `prep_midia.py ocultar` antes de usar |
| Fotos políticas desiguais | mesmo tratamento e moldura nas duas |
| Tag saindo pela borda | tags são presas entre x 90 e 990; mesmo assim, posicione perto do cartão |
| Muitos efeitos sonoros juntos | `"sfx": false` nas palavras secundárias |
| Tela com 16 palavras | dividir o bloco em dois na pausa mais próxima |
