# Direção de motion

## 1. Hierarquia (a decisão mais importante)
Cada tela tem **uma** palavra que manda. Pergunte: se a pessoa vir esta tela por meio segundo, sem som, que palavra ela precisa levar? Essa palavra vai em `impacto`, grande e, se for o conceito do vídeo, em `destaque`.

| Papel | Fonte | Tamanho | Cor |
|---|---|---|---|
| Dominante | impacto | 150 a 300 px | `destaque` (conceito) ou `texto` |
| Secundária | impacto | 100 a 140 px | `texto` |
| Ligação importante | ligacao | 86 a 110 px | `texto` |
| Ligação de passagem | ligacao | 60 a 90 px | `apoio` |

- Nunca duas dominantes do mesmo tamanho na mesma tela. Se há duas ideias fortes, são duas telas ou uma vira secundária.
- `destaque` em texto: no máximo 1 ou 2 palavras por tela. Se tudo é destaque, nada é.
- Números importantes quase sempre são dominantes (e muitas vezes `count`).
- Nome próprio na primeira aparição: `rise` + `texto`. Nas seguintes: ligação.

## 2. Movimento com significado
A animação traduz o sentido da palavra. Antes de escolher, pergunte o que a palavra **faz**:
- algo diminui → `shrink`; algo aumenta → `grow` ou `count`;
- algo é negado → `strike`; algo é julgado → `stamp`;
- algo é humano, feito à mão, pessoal → `draw`;
- algo é digital, artificial, falso → `glitch`;
- algo é sequência, processo → `step` ou `rise` em cascata;
- algo é citação de alguém → `mark`.
Na dúvida, use o padrão (`pop` / `blur`). Animação sem motivo cansa: no máximo 2 ou 3 animações "especiais" por tela.

## 3. Ritmo
- Telas de 2 a 6 s. Mais que 6 s sem mudança visual: adicione um evento (mídia, extra, troca de cor) no meio.
- Corte no fim da frase falada, nunca no meio de uma ideia.
- A primeira tela precisa de movimento nos primeiros 0,3 s (o gancho escrito aparece já).
- Entradas 0,05 a 0,1 s antes da fala. Saída de bloco: 0,18 s com desfoque (automática).
- Picos (`bg: destaque` + `wipe`): 3 a 4 por vídeo, em ordem crescente de importância. O último costuma ser a moral ou a pergunta final.

## 4. Composição
- Área segura: texto entre **x 90 e 990** e **y 250 e 1550**. Abaixo de 1550, a interface do app cobre (legenda, botões). Acima de 250 fica o cabeçalho.
- Sem mídia: `cy` 900 a 960. Com cartão no topo (y ≈ 640): `cy` 1250 a 1300.
- Cartões: 400 a 900 px de largura, rotação leve (−4° a +4°) alternando o lado entre telas, borda 6 px.
- Duas pessoas comparadas: cartões do mesmo tamanho, mesma borda, mesmo tratamento de imagem.
- Tag de mídia perto do canto superior do cartão, nunca sobre um rosto.

## 5. Cor
- `fundo` é a base. `destaque` é tempero.
- Em bloco `bg: destaque`, todo texto em `fundo`. O `checar` acusa texto da mesma cor do fundo.
- Fundo em vídeo/foto: escurecer 0,5 a 0,65 para o texto ler. Vídeo com legenda queimada: `desfoque` 7 + escurecer 0,5.

## 6. Som (automático, mas dirigido)
Efeitos sintetizados saem do json: whoosh nas trocas, pop no `pop`, lápis no `draw`, chiado no `glitch`, tic no `step`/`count`, carimbo no `stamp`, check nos `checks`. Se muitas palavras `pop` caem juntas, silencie algumas (`"sfx": false`): o som deve marcar picos, não cada palavra. Sem música no arquivo: o criador escolhe o áudio em alta no app.

## 7. Teste do sem-som
Olhe a grade sem ler o roteiro. A história se entende só pelas telas? Se uma tela depende do áudio para fazer sentido, falta uma palavra dominante ou uma mídia.
