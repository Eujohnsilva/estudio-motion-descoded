# Mídias: preparo, tratamento e créditos

## Preparo (`scripts/prep_midia.py`)
```bash
python3 $S/prep_midia.py info video.mov                                   # tamanho, duração, rotação
python3 $S/prep_midia.py frames video.mov pf --ini 3 --dur 9               # fundo 1080x1920, 30 fps
python3 $S/prep_midia.py frames video.mov card --dur 5 --cartao 400x640    # quadros para cartão
python3 $S/prep_midia.py frames video_com_legenda.mp4 bg --desfoque 7      # fundo com legenda queimada
python3 $S/prep_midia.py foto pessoa.jpg pessoa_pb.jpg --duotone --tam 420x620 --escuro "#0A0A0A" --claro "#F2F2EC"
python3 $S/prep_midia.py ocultar print.png print_ok.jpg --manter 120,640,520,140   # desfoca tudo menos o recorte
```
- Vídeo 4K ou rotacionado: o `frames` já recorta e corrige a orientação.
- Gere só o trecho usado (`--ini`, `--dur`): menos quadros, render mais rápido.
- Use as cores da marca no duotone.

## Tratamento
- **Pessoas em comparação** (política, antes e depois, rivais): o mesmo tratamento para todas (duotone ou P&B), mesmo enquadramento, mesma moldura. Foto de campanha contra retrato oficial é desequilíbrio editorial.
- **Prints com dados pessoais ou conteúdo sensível** (nomes, telefones, menção a autolesão): `ocultar`, deixando nítido só o trecho que importa.
- **Imagem gerada por IA** usada como ilustração: tag "imagem gerada por IA" no vídeo e aviso na legenda.
- **Vídeo de terceiros:** trecho curto, para comentário ou crítica, com tag "vídeo original" e crédito na legenda.
- **Referência de formato** (o vídeo de outro criador que inspirou): se aparecer, tag "referência de formato" e crédito.

## Onde conseguir
- Do próprio criador (sempre a primeira opção).
- Imagens oficiais de imprensa (press kit, sala de imprensa do órgão ou da empresa).
- Bancos com licença clara. Não baixe fotos de pessoas públicas da web para colocar no vídeo; peça ao criador que forneça as imagens que ele tem direito de usar.

## Créditos
Liste toda mídia de terceiros na ficha do vídeo (arquivo → origem). A skill de legenda usa essa lista.
