# Alinha o texto da narração ao áudio, sem modelo de transcrição.
# 1) detecta trechos de fala pelas pausas (ffmpeg silencedetect)
# 2) distribui as palavras entre os trechos por programação dinâmica (duração esperada por sílabas,
#    com preferência por cortes em pontuação)
# 3) dentro de cada trecho, o tempo de cada palavra é proporcional às sílabas
# Uso: python3 align.py texto.txt narracao.mp3 tempos.json [--ruido -36] [--pausa 0.1] [--pron "claude=clód,after=áfter"]
import re, json, subprocess, sys, argparse
ap = argparse.ArgumentParser()
ap.add_argument('texto'); ap.add_argument('audio'); ap.add_argument('saida')
ap.add_argument('--ruido', type=float, default=-36); ap.add_argument('--pausa', type=float, default=0.1)
ap.add_argument('--pron', default=''); ap.add_argument('--ini', type=float, default=0); ap.add_argument('--fim', type=float, default=0)
A = ap.parse_args()
TXT = open(A.texto, encoding='utf-8').read().strip()
TOTAL = float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',A.audio],capture_output=True,text=True).stdout)
PRON = {'elevenlabs':'ílevenlébs','after':'áfter','effects':'iféquts','claude':'clód','youtube':'iutúbi','instagram':'instagrã','tiktok':'tiquitóqui','iphone':'aifône','google':'gúgou','online':'onlaine','design':'dizáine','reels':'ríous','feed':'fíidi','show':'xou','app':'épi'}
for kv in filter(None, A.pron.split(',')):
    k, v = kv.split('='); PRON[k.strip().lower()] = v.strip()
words = TXT.split()
def syl(w):
    lw = re.sub(r'[^\wáéíóúâêôãõàç%]', '', w.lower())
    lw = PRON.get(lw, lw)
    if re.fullmatch(r'\d+([.,]\d+)?%?', lw): return max(2, 2 * len(re.sub(r'\D', '', lw)))
    return max(1, len(re.findall(r'[aeiouáéíóúâêôãõà]+', lw)))
S = [syl(w) for w in words]
cmd = f'ffmpeg -i "{A.audio}" -af silencedetect=noise={A.ruido}dB:d={A.pausa} -f null - 2>&1 | grep -oE "silence_(start|end): [0-9.]+" | awk \'{{print $2}}\''
v = list(map(float, subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.split()))
segs = []; st = 0.0
for i in range(0, len(v) - 1, 2):
    if v[i] - st > 0.12: segs.append((st, v[i]))
    st = v[i + 1]
if len(v) % 2 == 1:  # áudio termina em silêncio
    if v[-1] - st > 0.12: segs.append((st, v[-1]))
elif TOTAL - st > 0.12: segs.append((st, TOTAL))
if not segs: segs = [(0.0, TOTAL)]
N = len(words); M = len(segs)
rate = sum(S) / sum(b - a for a, b in segs)
INF = 1e18
dp = [[INF] * (M + 1) for _ in range(N + 1)]; bk = [[None] * (M + 1) for _ in range(N + 1)]
dp[0][0] = 0; pref = [0]
for s in S: pref.append(pref[-1] + s)
for j in range(1, M + 1):
    a, b = segs[j - 1]; d = b - a
    for i in range(0, N + 1):
        if dp[i][j - 1] >= INF: continue
        if d < 0.25 and dp[i][j - 1] + 0.5 < dp[i][j]: dp[i][j] = dp[i][j - 1] + 0.5; bk[i][j] = i
        for k in range(i + 1, min(N, i + 25) + 1):
            exp = (pref[k] - pref[i]) / rate
            c = (exp - d) ** 2 / (d + 0.3)
            if not re.search(r'[.,?!:;]["”]?$|\.\.\.$', words[k - 1]) and k < N: c += 0.3
            if dp[i][j - 1] + c < dp[k][j]: dp[k][j] = dp[i][j - 1] + c; bk[k][j] = i
if dp[N][M] >= INF:
    sys.exit('ERRO: não foi possível alinhar. Confira se o texto é exatamente o que foi falado, ou ajuste --ruido/--pausa.')
i = N; assign = []
for j in range(M, 0, -1):
    p = bk[i][j]; assign.append((segs[j - 1], words[p:i], S[p:i])); i = p
assign.reverse()
WT = []; SEG = []
for (a, b), ws, ss in assign:
    if not ws: continue
    tot = sum(ss); acc = 0
    print(f"{a:6.2f}-{b:6.2f}  {' '.join(ws)}")
    SEG.append([round(a, 2), round(b, 2), ' '.join(ws)])
    for w, s in zip(ws, ss): WT.append([w, round(a + (b - a) * acc / tot, 2)]); acc += s
json.dump(WT, open(A.saida, 'w'), ensure_ascii=False)
json.dump(SEG, open(re.sub(r'\.json$', '', A.saida) + '_trechos.json', 'w'), ensure_ascii=False, indent=0)
fala = sum(b - a for a, b in segs)
print(f'CUSTO {dp[N][M]:.2f} · {N} palavras · {M} trechos · duração {TOTAL:.2f}s · ritmo {N / fala:.2f} palavras/s de fala')
if dp[N][M] / max(1, M) > 0.35: print('AVISO: custo alto por trecho. O texto pode não ser igual ao áudio; confira as frases acima.')
