# Preparo de mídias para o motor.
#   frames  ENTRADA.mp4 PASTA [--ini 3 --dur 6] [--desfoque 7] [--cartao 420x620]  -> PASTA/f0001.jpg... (30 fps)
#   foto    ENTRADA OUT.jpg [--pb] [--duotone] [--tam 900x1200]                   -> foto tratada (mesmo tratamento para todas)
#   ocultar ENTRADA OUT.jpg --manter x,y,w,h [--raio 9]                            -> desfoca tudo, menos o recorte
#   info    ARQUIVO                                                                 -> tamanho, duração, rotação
import sys, os, subprocess, argparse, json
from PIL import Image, ImageOps, ImageFilter
ap = argparse.ArgumentParser(); ap.add_argument('cmd'); ap.add_argument('entrada'); ap.add_argument('saida', nargs='?')
ap.add_argument('--ini', type=float, default=0); ap.add_argument('--dur', type=float, default=0); ap.add_argument('--desfoque', type=float, default=0)
ap.add_argument('--cartao', default=None); ap.add_argument('--pb', action='store_true'); ap.add_argument('--duotone', action='store_true')
ap.add_argument('--tam', default=None); ap.add_argument('--manter', default=None); ap.add_argument('--raio', type=float, default=9)
ap.add_argument('--escuro', default='#0A0A0A'); ap.add_argument('--claro', default='#F2F2EC')
A = ap.parse_args()
if A.cmd == 'info':
    print(subprocess.run(['ffprobe','-v','error','-show_entries','stream=width,height,codec_type:stream_side_data=rotation:format=duration','-of','json',A.entrada],capture_output=True,text=True).stdout); sys.exit()
if A.cmd == 'frames':
    os.makedirs(A.saida, exist_ok=True)
    w, h = (1080, 1920) if not A.cartao else map(int, A.cartao.split('x'))
    vf = f'fps=30,scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}'
    if A.desfoque: vf += f',gblur=sigma={A.desfoque}'
    cmd = ['ffmpeg','-y','-loglevel','error']
    if A.ini: cmd += ['-ss', str(A.ini)]
    cmd += ['-i', A.entrada]
    if A.dur: cmd += ['-t', str(A.dur)]
    cmd += ['-vf', vf, '-q:v', '3', os.path.join(A.saida, 'f%04d.jpg')]
    subprocess.run(cmd, check=True)
    print('ok', len([f for f in os.listdir(A.saida) if f.endswith('.jpg')]), 'quadros em', A.saida)
if A.cmd == 'foto':
    im = ImageOps.exif_transpose(Image.open(A.entrada)).convert('RGB')
    if A.tam:
        w, h = map(int, A.tam.split('x')); im = ImageOps.fit(im, (w, h), Image.LANCZOS, centering=(0.5, 0.35))
    if A.duotone: im = ImageOps.colorize(ImageOps.autocontrast(im.convert('L'), cutoff=1), A.escuro, A.claro)
    elif A.pb: im = ImageOps.autocontrast(im.convert('L'), cutoff=1).convert('RGB')
    im.save(A.saida, quality=92); print('ok', A.saida, im.size)
if A.cmd == 'ocultar':
    im = ImageOps.exif_transpose(Image.open(A.entrada)).convert('RGB'); x, y, w, h = map(int, A.manter.split(','))
    keep = im.crop((x, y, x + w, y + h)); out = im.filter(ImageFilter.GaussianBlur(A.raio)); out.paste(keep, (x, y))
    out.save(A.saida, quality=92); print('ok', A.saida)
