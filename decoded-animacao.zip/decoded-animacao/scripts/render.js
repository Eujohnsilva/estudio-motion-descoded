// Render do motor pelo Chromium (Playwright) -> ffmpeg.
// Uso:
//   node render.js VIDEO.json lint                         -> revisão automática (layout, contraste, tempos)
//   node render.js VIDEO.json still 2.4 6.6 10.9 [--out d] -> PNGs dos instantes
//   node render.js VIDEO.json video [--out video_tmp.mp4]  -> vídeo sem áudio, 30 fps
//   node render.js - assinatura [--out sig_v.mp4]          -> vinheta final da marca (3,2 s)
// A marca vem de --marca brand.json, ou de "marca" no video.json, ou é procurada automaticamente.
const {spawn,execSync}=require('child_process');
let PW;try{PW=require('playwright');}catch(e){const roots=[];try{roots.push(execSync('npm root -g').toString().trim());}catch(_){}roots.push('/usr/local/lib/node_modules_global','/usr/local/lib/node_modules','/opt/npm-tools/node_modules');for(const r of roots){try{PW=require(r+'/playwright');break;}catch(_){}}if(!PW){console.error('ERRO: playwright não encontrado. Rode scripts/preparar.sh');process.exit(3);}}
const {chromium}=PW;const fs=require('fs');const path=require('path');
const args=process.argv.slice(2);const flag=(k,d)=>{const i=args.indexOf(k);if(i<0)return d;const v=args[i+1];args.splice(i,2);return v;};
const OUT=flag('--out',null), MARCA=flag('--marca',null);
const vjson=args[0], mode=args[1], rest=args.slice(2);
function findBrand(vdir,v){
  const c=[MARCA, v&&v.marca&&path.resolve(vdir,v.marca), path.join(vdir,'brand.json'), path.join(vdir,'marca/brand.json')].filter(Boolean);
  for(const p of c) if(fs.existsSync(p)) return p;
  try{const r=execSync("find / -path '*decoded-marca/brand.json' -not -path '*/proc/*' 2>/dev/null | head -1").toString().trim();if(r)return r;}catch(e){}
  try{const r=execSync("find /mnt/user-data /mnt/project -name 'brand.json' 2>/dev/null | head -1").toString().trim();if(r)return r;}catch(e){}
  console.error('ERRO: brand.json não encontrado. Rode a configuração de marca ou passe --marca.');process.exit(2);
}
(async()=>{
  const vdir=vjson&&vjson!=='-'?path.dirname(path.resolve(vjson)):process.cwd();
  const video=vjson&&vjson!=='-'?JSON.parse(fs.readFileSync(vjson,'utf8')):{blocos:[]};
  const bpath=findBrand(vdir,video);const brand=JSON.parse(fs.readFileSync(bpath,'utf8'));
  // conta os quadros das pastas de vídeo (f0001.jpg...)
  for(const bl of video.blocos||[])for(const m of (bl.midias||[]))if(m.frames&&!m.n){const d=path.resolve(vdir,m.frames);m.n=fs.existsSync(d)?fs.readdirSync(d).filter(f=>/^f\d+\.jpg$/.test(f)).length:1;if(m.n===0)console.error('AVISO: pasta sem quadros',d);}
  for(const bl of video.blocos||[])for(const m of (bl.midias||[]))if(m.src&&!/^(\/|file:|data:|https?:)/.test(m.src)&&!fs.existsSync(path.resolve(vdir,m.src)))console.error('AVISO: mídia não encontrada',m.src);
  const b=await chromium.launch({args:['--allow-file-access-from-files']});
  const p=await b.newPage({viewport:{width:1080,height:1920}});
  await p.goto('file://'+path.join(__dirname,'pagina.html'));
  await p.evaluate(async([br,v,ctx])=>{await setup(br,v,ctx);},[brand,video,{base:vdir,marcaDir:path.dirname(bpath)}]);
  const ferr=await p.evaluate(()=>window.__fontErr||[]);if(ferr.length)console.error('AVISO fontes:',ferr.join(' | '));
  const wait=async()=>{await p.evaluate(()=>Promise.all([...document.images].map(i=>i.decode?i.decode().catch(()=>0):0)));};
  if(mode==='lint'){const r=await p.evaluate(()=>lint());
    if(!r.issues.length)console.log('OK: nenhum problema encontrado em',video.blocos.length,'blocos');
    else{console.log(r.issues.length+' ponto(s) para revisar:');for(const i of r.issues)console.log(' - bloco',i.bloco+':',i.msg);}
  }else if(mode==='still'){const od=OUT||'.';fs.mkdirSync(od,{recursive:true});
    for(const t of rest){await p.evaluate(t=>draw(t),parseFloat(t));await p.waitForTimeout(30);await p.screenshot({path:path.join(od,`still_${t}.png`)});}
    console.log('salvo(s) em',od);
  }else if(mode==='video'||mode==='assinatura'){
    const dur=mode==='assinatura'?3.2:parseFloat(rest[0]||video.duracao),fps=30,out=OUT||(mode==='assinatura'?'sig_v.mp4':'video_tmp.mp4');
    const fn=mode==='assinatura'?'drawSig':'draw';
    const ff=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-framerate','30','-i','-','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',out]);
    const N=Math.round(dur*fps);let last=Date.now();
    for(let k=0;k<N;k++){await p.evaluate(([f,t])=>window[f](t),[fn,k/fps]);
      if(/<image/.test(await p.evaluate(()=>document.getElementById('s').innerHTML.slice(0,20000))))await wait();
      const buf=await p.screenshot({type:'jpeg',quality:92});if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
      if(Date.now()-last>15000){console.log(`  ${k}/${N} quadros`);last=Date.now();}}
    ff.stdin.end();await new Promise(r=>ff.on('close',r));console.log('ok',out,N,'quadros');
  }else{console.error('modo desconhecido:',mode);}
  await b.close();
})();
