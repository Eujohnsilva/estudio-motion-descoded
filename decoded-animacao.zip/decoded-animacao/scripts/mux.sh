#!/usr/bin/env bash
# Junta vídeo + narração + efeitos, normaliza em -14 LUFS (pico -1,5 dBTP) e anexa a assinatura.
# Uso: ./mux.sh video_tmp.mp4 narracao.mp3 sfx.wav DURACAO SAIDA.mp4 [assinatura.mp4]
set -e
V=$1; N=$2; S=$3; D=$4; OUT=$5; SIG=$6
ffmpeg -y -loglevel error -i "$V" -i "$N" -i "$S" -filter_complex \
 "[1:a]aresample=44100,apad[n];[2:a]volume=0.8[s];[n][s]amix=inputs=2:duration=longest:normalize=0,atrim=0:$D,loudnorm=I=-14:TP=-1.5:LRA=11,aformat=channel_layouts=stereo[a]" \
 -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -t "$D" body.mp4
if [ -n "$SIG" ] && [ -f "$SIG" ]; then
ffmpeg -y -loglevel error -i body.mp4 -i "$SIG" -filter_complex \
 "[0:v]setpts=PTS-STARTPTS[v0];[0:a]aresample=44100,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a0];[1:v]setpts=PTS-STARTPTS[v1];[1:a]aresample=44100,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]" \
 -map "[v]" -map "[a]" -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart "$OUT"
else
ffmpeg -y -loglevel error -i body.mp4 -c copy -movflags +faststart "$OUT"
fi
rm -f body.mp4
