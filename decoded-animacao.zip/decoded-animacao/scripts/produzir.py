# Linha de produção do vídeo. Rode da pasta do vídeo.
#   alinhar  TEXTO.txt NARRACAO.mp3 [--pron "nome=pronúncia"]   -> tempos.json + tempos_trechos.json
#   checar   video.json                                         -> revisão automática do layout
#   quadros  video.json [t1 t2 ...]                             -> grade.png (sem tempos: fim de cada bloco)
#   final    video.json NARRACAO.mp3 SAIDA.mp4 [--sem-assinatura]
#   conferir SAIDA.mp4                                          -> duração, volume e 4 quadros (conferencia.png)
import sys, os, subprocess, json, glob, argparse, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
def run(c, **k): print('$', ' '.join(c) if isinstance(c, list) else c); return subprocess.run(c, check=True, **k)
def grid(paths, out, labels=None, cols=4, w=270):
    from PIL import Image, ImageDraw, ImageFont
    h = int(w * 1920 / 1080); rows = (len(paths) + cols - 1) // cols
    G = Image.new('RGB', (cols * w, rows * (h + 34)), (30, 30, 30)); d = ImageDraw.Draw(G)
    try: F = ImageFont.truetype('/usr/share/fonts/opentype/inter/Inter-SemiBold.otf', 20)
    except Exception: F = ImageFont.load_default()
    for i, p in enumerate(paths):
        im = Image.open(p).convert('RGB').resize((w, h)); x, y = (i % cols) * w, (i // cols) * (h + 34)
        # guias de área segura: x 90-990, y 250-1550 (abaixo de 1550 a interface cobre)
        s = w / 1080; dd = ImageDraw.Draw(im)
        dd.rectangle([90 * s, 250 * s, 990 * s, 1550 * s], outline=(255, 60, 90)); dd.rectangle([0, 1550 * s, w, h], fill=None, outline=(255, 60, 90))
        G.paste(im, (x, y)); d.text((x + 8, y + h + 6), labels[i] if labels else os.path.basename(p), fill=(230, 230, 230), font=F)
    G.save(out); print('grade:', out)
def probe(f, what='format=duration'):
    return subprocess.run(['ffprobe', '-v', 'error', '-show_entries', what, '-of', 'csv=p=0', f], capture_output=True, text=True).stdout.strip()
cmd = sys.argv[1] if len(sys.argv) > 1 else ''
if cmd == 'alinhar':
    run(['python3', os.path.join(HERE, 'align.py'), sys.argv[2], sys.argv[3], 'tempos.json'] + sys.argv[4:])
elif cmd == 'checar':
    run(['node', os.path.join(HERE, 'render.js'), sys.argv[2], 'lint'] + sys.argv[3:])
elif cmd == 'quadros':
    V = json.load(open(sys.argv[2], encoding='utf-8')); ts = sys.argv[3:]
    if not ts: ts = [f"{max(b['a'], b['b'] - 0.25):.2f}" for b in V['blocos']]
    od = 'revisao'; shutil.rmtree(od, ignore_errors=True)
    run(['node', os.path.join(HERE, 'render.js'), sys.argv[2], 'still'] + ts + ['--out', od])
    grid([f'{od}/still_{t}.png' for t in ts], 'grade.png', [f'{t}s' for t in ts])
elif cmd == 'final':
    ap = argparse.ArgumentParser(); ap.add_argument('c'); ap.add_argument('video'); ap.add_argument('narracao'); ap.add_argument('saida'); ap.add_argument('--sem-assinatura', action='store_true'); ap.add_argument('--marca', default=None)
    A = ap.parse_args(); V = json.load(open(A.video, encoding='utf-8')); D = V['duracao']
    mk = ['--marca', A.marca] if A.marca else []
    run(['node', os.path.join(HERE, 'render.js'), A.video, 'lint'] + mk)
    run(['node', os.path.join(HERE, 'render.js'), A.video, 'video', str(D), '--out', 'video_tmp.mp4'] + mk)
    run(['python3', os.path.join(HERE, 'sfx.py'), A.video, 'sfx.wav'])
    sig = ''
    if not A.sem_assinatura and V.get('assinatura', True):
        run(['node', os.path.join(HERE, 'render.js'), A.video, 'assinatura', '--out', 'sig_v.mp4'] + mk)
        run(['python3', os.path.join(HERE, 'sfx.py'), '--assinatura', 'sig.wav'])
        run(['ffmpeg', '-y', '-loglevel', 'error', '-i', 'sig_v.mp4', '-i', 'sig.wav', '-af', 'loudnorm=I=-16:TP=-1.5', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', 'assinatura.mp4'])
        sig = 'assinatura.mp4'
    run(['bash', os.path.join(HERE, 'mux.sh'), 'video_tmp.mp4', A.narracao, 'sfx.wav', str(D), A.saida] + ([sig] if sig else []))
    sys.argv = ['', 'conferir', A.saida]; cmd = 'conferir'
if cmd == 'conferir':
    f = sys.argv[2]; d = float(probe(f))
    print(f'duração: {d:.2f}s · vídeo: {probe(f, "stream=width,height,r_frame_rate,codec_name")}')
    lufs = subprocess.run(['ffmpeg', '-i', f, '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True).stderr
    li = [l for l in lufs.splitlines() if l.strip().startswith('I:')]; print('volume integrado:', li[-1].strip() if li else '?')
    os.makedirs('conferencia', exist_ok=True); ps = []
    for i, t in enumerate([0.8, d * 0.35, d * 0.7, max(0, d - 1.0)]):
        p = f'conferencia/q{i}.png'; subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-ss', f'{t:.2f}', '-i', f, '-frames:v', '1', p]); ps.append(p)
    grid(ps, 'conferencia.png', [f'{t:.1f}s' for t in [0.8, d * 0.35, d * 0.7, max(0, d - 1.0)]])
