# Efeitos sonoros sintetizados (sem licença de terceiros), gerados a partir do video.json.
#  whoosh: troca de bloco (mais forte no wipe) · pop: palavras "pop" · lápis: "draw" · chiado: "glitch"
#  tic: "step" e "count" · carimbo: "stamp" · check: extra "checks" · digitação: "type"/"codigo"
# Uso: python3 sfx.py video.json sfx.wav [--volume 1.0]      |  python3 sfx.py --assinatura sig.wav
# Para silenciar um efeito numa palavra: {"sfx": false} nas opções dela. No vídeo inteiro: "sfx": false.
import numpy as np, wave, json, sys, argparse
ap = argparse.ArgumentParser(); ap.add_argument('video', nargs='?'); ap.add_argument('saida', nargs='?', default='sfx.wav')
ap.add_argument('--assinatura', default=None); ap.add_argument('--volume', type=float, default=1.0)
A = ap.parse_args()
SR = 44100; rng = np.random.default_rng(4)
def tone(f, d, dec, v): tt = np.arange(int(d * SR)) / SR; return v * np.sin(2 * np.pi * f * tt) * np.exp(-tt * dec)
def whoosh(d=0.45, c=1800, v=0.15):
    n = int(d * SR); x = rng.standard_normal(n); sp = np.fft.rfft(x); fr = np.fft.rfftfreq(n, 1 / SR)
    sp *= np.exp(-((fr - c) / 1400) ** 2); w = np.fft.irfft(sp, n); w /= np.abs(w).max(); return v * w * np.sin(np.pi * np.arange(n) / n) ** 2
def pop(v=0.13): tt = np.arange(int(0.09 * SR)) / SR; return v * np.sin(2 * np.pi * (500 + 2500 * tt) * tt) * np.exp(-tt * 30)
def pencil(d=0.9, v=0.05):
    n = int(d * SR); x = rng.standard_normal(n); sp = np.fft.rfft(x); fr = np.fft.rfftfreq(n, 1 / SR); sp *= np.exp(-((fr - 4500) / 2500) ** 2)
    w = np.fft.irfft(sp, n); w /= np.abs(w).max(); return v * w * (0.6 + 0.4 * np.sin(np.arange(n) / SR * 2 * np.pi * 9))
def glitch(v=0.06): n = int(0.25 * SR); return v * np.sign(np.sin(np.arange(n) / SR * 2 * np.pi * 220)) * (rng.random(n) > 0.5)
def key(v=0.03): n = int(0.03 * SR); return v * rng.standard_normal(n) * np.exp(-np.arange(n) / SR * 120)
def write(a, path):
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(a, -1, 1) * 32767).astype(np.int16).tobytes())
if A.assinatura:
    a = np.zeros(int(SR * 3.2))
    def add(t, s): i = int(t * SR); n = min(len(s), len(a) - i); a[i:i + n] += s[:n]
    add(0.0, whoosh(0.6, 1400, 0.16))
    for t in (0.42, 0.5, 0.58, 0.66): add(t, tone(880, 0.12, 25, 0.05))
    add(0.62, tone(660, 0.6, 5, 0.06)); add(0.62, tone(990, 0.6, 6, 0.04))
    for t in (1.45, 1.65, 1.85, 2.05): add(t, pop(0.06))
    write(a * A.volume, A.assinatura); print('ok', A.assinatura); sys.exit()
V = json.load(open(A.video, encoding='utf-8'))
D = V['duracao']; a = np.zeros(int(SR * (D + 1)))
def add(t, s):
    if t < 0: t = 0
    i = int(t * SR); n = min(len(s), len(a) - i)
    if n > 0: a[i:i + n] += s[:n]
if V.get('sfx', True):
    for k, bl in enumerate(V['blocos']):
        if k > 0: add(bl['a'] - 0.12, whoosh(0.5, 1500, 0.18) if bl.get('wipe') else whoosh())
        for line in bl.get('linhas', bl.get('lines', [])):
            for w in line:
                if isinstance(w, list):
                    t, f, at = w[0], w[1], w[4]; an = w[5] if len(w) > 5 and w[5] else ('pop' if f in ('impacto', 'sans') else 'blur'); op = w[6] if len(w) > 6 else {}
                else: t, at, an, op = w['t'], w['at'], w.get('a', 'blur'), w
                if op.get('sfx') is False: continue
                if an == 'pop': add(at, pop())
                elif an == 'draw': add(at, pencil())
                elif an == 'glitch': add(at, glitch())
                elif an in ('step',): add(at, tone(1500, 0.05, 50, 0.06))
                elif an == 'count':
                    for q in np.arange(0, op.get('dur', 0.55), 0.07): add(at + q, tone(1800, 0.03, 80, 0.03))
                elif an == 'stamp': add(at, tone(120, 0.2, 18, 0.25))
                elif an in ('strike', 'strike2'): add(at + 0.35, whoosh(0.25, 3000, 0.06))
                elif an == 'type':
                    for q in np.arange(0, len(t) * 0.04, 0.05): add(at + q, key())
        for e in bl.get('extras', []):
            if e.get('tipo') == 'checks':
                for tt in e.get('at', []): add(tt, tone(1320, 0.15, 15, 0.06))
            if e.get('tipo') == 'codigo':
                for q in np.arange(0, len(e['texto']) * 0.04, 0.05): add(e['at'] + q, key())
            if e.get('tipo') in ('selo', 'linha_tempo', 'calendario'): add(e.get('at', bl['a']), pop(0.08))
        for m in bl.get('midias', []):
            if m.get('tipo') == 'cartao': add(m.get('at', bl['a']), whoosh(0.3, 2400, 0.07))
            if (m.get('efeito') or {}).get('tipo') == 'pixelar': add(m['efeito']['at'], glitch(0.04))
write(a[:int(SR * D)] * A.volume, A.saida); print('ok', A.saida)
