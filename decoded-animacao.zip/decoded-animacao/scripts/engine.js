// Motor de tipografia cinética · 1080x1920 · determinístico (cada quadro depende só de t)
// Não edite este arquivo por vídeo. Cada vídeo é descrito em video.json e cada marca em brand.json.
// O render.js chama: await setup(brand, video, ctx)  ->  draw(t)  /  lint()  /  drawSig(u)
"use strict";
let BR = null, V = null, C = {}, FT = {}, BASE = "", MARCA_DIR = "", DUR = 0;
const SAFE = { x0: 90, x1: 990, y0: 250, y1: 1550, maxLine: 900 };

const cl = t => Math.max(0, Math.min(1, t));
const eo = t => 1 - Math.pow(1 - cl(t), 4);                                         // entradas
const eio = t => { t = cl(t); return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2 }; // movimentos e wipes
const eb = t => { t = cl(t); const c = 1.5; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2) }; // pops com exagero
const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const col = x => (x && C[x]) || x || C.texto;
const href = p => !p ? "" : /^(file:|data:|https?:)/.test(p) ? p : p.startsWith("/") ? "file://" + p : "file://" + BASE + "/" + p;

// ---------- configuração ----------
const FAM = { impacto: "F_IMP", ligacao: "F_LIG", rotulo: "F_ROT", codigo: "F_COD" };
const ALIAS = { sans: "impacto", imp: "impacto", impacto: "impacto", serif: "ligacao", lig: "ligacao", ligacao: "ligacao", mono: "codigo", codigo: "codigo", rotulo: "rotulo" };
async function setup(brand, video, ctx) {
  BR = brand; V = video || {}; BASE = (ctx && ctx.base) || ""; MARCA_DIR = (ctx && ctx.marcaDir) || "";
  const k = brand.cores || {};
  C = {
    fundo: k.fundo || "#0A0A0A", texto: k.texto || "#F2F2EC", destaque: k.destaque || "#C8FF2E",
    apoio: k.apoio || "#A9A9A2", rotulo: k.rotulo || "#7C7C76", card: k.card || "#151515", linha: k.linha || "#2A2A2A",
    glitch1: (k.glitch || [])[0] || "#FF3B6B", glitch2: (k.glitch || [])[1] || "#3BD8FF"
  };
  // aliases de cor para quem escreve o video.json
  Object.assign(C, { INK: C.fundo, PAPER: C.texto, LIME: C.destaque, MUTE: C.apoio, GREY: C.rotulo, tinta: C.fundo, papel: C.texto });
  const f = brand.fontes || {};
  const def = {
    impacto: { arquivo: "/usr/share/fonts/opentype/inter/InterDisplay-ExtraBold.otf", peso: 800, italico: false },
    ligacao: { arquivo: "/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf", peso: 500, italico: true },
    rotulo: { arquivo: "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", peso: 600, italico: false },
    codigo: { arquivo: "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", peso: 400, italico: false }
  };
  const loads = [];
  for (const r of Object.keys(def)) {
    const spec = Object.assign({}, def[r], f[r] || {});
    if (f[r] && f[r].familia && !f[r].arquivo) spec.arquivo = null;
    FT[r] = { fam: FAM[r], peso: spec.peso, italico: !!spec.italico, tracking: spec.tracking || 0 };
    let src;
    if (spec.arquivo) { const p = spec.arquivo.startsWith("/") ? spec.arquivo : MARCA_DIR + "/" + spec.arquivo; src = `url("file://${p}")`; }
    else src = `local("${spec.familia}")`;
    const ff = new FontFace(FAM[r], src, { style: spec.italico ? "italic" : "normal", weight: String(spec.peso) });
    document.fonts.add(ff); loads.push(ff.load().catch(e => { window.__fontErr = (window.__fontErr || []).concat(r + ": " + e); }));
  }
  await Promise.all(loads);
  DUR = V.duracao || 0;
  // normaliza blocos e palavras
  (V.blocos || []).forEach(bl => {
    bl.bg = bl.bg || "fundo";
    bl.lines = (bl.linhas || bl.lines || []).map(l => l.map(w => Array.isArray(w) ? normW(w) : w));
  });
  return true;
}
function normW(a) { // ["texto","ligacao",96,"texto",1.23,"blur",{opções}]
  const o = Object.assign({ t: a[0], f: ALIAS[a[1]] || "ligacao", s: a[2], c: a[3], at: a[4], a: a[5] || (ALIAS[a[1]] === "impacto" ? "pop" : "blur") }, a[6] || {});
  return o;
}
function fnt(w) { const r = FT[w.f] || FT.ligacao; return { fam: r.fam, attr: `font-family="${r.fam}" font-weight="${r.peso}"${r.italico ? ' font-style="italic"' : ""}${r.tracking ? ` letter-spacing="${r.tracking}"` : ""}`, css: `${r.italico ? "italic " : ""}${r.peso} `, tr: r.tracking } }
const cv = document.createElement("canvas").getContext("2d");
function tw(txt, w, s) { const F = fnt(w); cv.font = F.css + s + "px " + F.fam; let x = cv.measureText(txt).width; if (F.tr) x += F.tr * Math.max(0, txt.length - 1); return x; }
function rotW(txt, s) { cv.font = `${FT.rotulo.peso} ${s}px F_ROT`; return cv.measureText(txt).width; }

// ---------- layout com auto-ajuste ----------
function layout(bl) {
  const lines = bl.lines.map(l => {
    let sz = l.map(w => w.s);
    const gapOf = ss => Math.max(ss[0] * 0.26, Math.max(...ss) * 0.2);
    let ws = l.map((w, k) => tw(w.a === "count" ? String(w.t) : w.t, w, sz[k]));
    let lw = ws.reduce((a, b) => a + b, 0) + gapOf(sz) * (l.length - 1);
    let fit = 1;
    if (lw > SAFE.maxLine) { fit = SAFE.maxLine / lw; sz = sz.map(s => s * fit); ws = l.map((w, k) => tw(w.a === "count" ? String(w.t) : w.t, w, sz[k])); lw = ws.reduce((a, b) => a + b, 0) + gapOf(sz) * (l.length - 1); }
    return { l, sz, ws, lw, gap: gapOf(sz), fit };
  });
  const hs = lines.map(L => Math.max(...L.sz) * 0.98 + Math.max(...L.l.map(w => w.pad || 0)));
  const tot = hs.reduce((a, b) => a + b, 0) + (hs.length - 1) * 18;
  let y = (bl.cy || 960) - tot / 2;
  const out = [];
  lines.forEach((L, i) => {
    const pd = Math.max(...L.l.map(w => w.pad || 0));
    const align = bl.alinhar || "centro";
    let x = align === "esquerda" ? SAFE.x0 : 540 - L.lw / 2;
    const base = y + pd * 0.5 + (hs[i] - pd) * 0.80;
    L.l.forEach((w, k) => { out.push({ w, s: L.sz[k], x, y: base, wd: L.ws[k], fit: L.fit, line: i }); x += L.ws[k] + L.gap; });
    y += hs[i] + 18;
  });
  return out;
}

// ---------- palavras ----------
function word(o, t, bl) {
  const w = o.w, u = t - w.at; if (u < 0) return "";
  const F = fnt(w), s = o.s, c = col(w.c);
  const cx = o.x + o.wd / 2, cy = o.y - s * 0.35;
  let op = 1, blur = 0, sc = 1, dy = 0, txt = w.t, extra = "";
  const T = (x, y, fill, more = "") => `<text x="${x}" y="${y}" ${F.attr} font-size="${s.toFixed(1)}" fill="${fill}" ${more}>${esc(txt)}</text>`;
  switch (w.a) {
    case "none": break;
    case "blur": { const p = eo(u / 0.35); op = p; blur = (1 - p) * 16; sc = 1.12 - 0.12 * p; break; }
    case "rise": { const p = eo(u / 0.4); op = cl(u / 0.15); dy = (1 - p) * 70; break; }
    case "pop": { sc = eb(u / 0.45); op = cl(u / 0.08); blur = (1 - cl(u / 0.2)) * 10; break; }
    case "shrink": { const p = eb(u / 0.35); const q = eio((u - 0.4) / 0.9); sc = p * (1.08 - 0.22 * q); op = cl(u / 0.08); break; }
    case "grow": { const p = eb(u / 0.35); const q = eio((u - 0.4) / 0.9); sc = p * (0.9 + 0.2 * q); op = cl(u / 0.08); break; }
    case "count": { const d = w.dur || 0.55, from = w.from || 0; const n = parseFloat(String(w.t).replace(",", ".")); const p = eo(u / d);
      const dec = (String(w.t).split(/[.,]/)[1] || "").length; let v = from + (n - from) * p; txt = (dec ? v.toFixed(dec).replace(".", ",") : String(Math.round(v)).padStart(w.pad0 || 1, "0")) + (w.suf || "");
      sc = 0.85 + 0.15 * eb(u / 0.35); op = cl(u / 0.08); break; }
    case "draw": { const k = eio(u / 0.9), f = cl((u - 0.7) / 0.3);
      return T(o.x, o.y, c, `fill-opacity="${f.toFixed(3)}" stroke="${c}" stroke-width="2.5" stroke-dasharray="1400" stroke-dashoffset="${(1400 * (1 - k)).toFixed(0)}"`); }
    case "glitch": { op = cl(u / 0.05); if (u < 0.35) { const j = (u * 97 % 1) * 14 - 7;
        return `<g opacity="${op}">${T(o.x + j, o.y, C.glitch1, 'opacity=".7"')}${T(o.x - j, o.y + 3, C.glitch2, 'opacity=".7"')}${T(o.x, o.y, c)}</g>`; } break; }
    case "step": { const st = Math.floor(u * 8) / 8; sc = st < 0.25 ? 0.6 : st < 0.5 ? 1.15 : 1; break; }
    case "stamp": { const p = eb(u / 0.3); sc = 2.2 - 1.2 * p; op = cl(u / 0.08); break; }
    case "initial": { const p = eo(u / 0.4); op = cl(u / 0.12); dy = (1 - p) * 60;
      return `<g opacity="${op}" transform="translate(0 ${dy})"><text x="${o.x}" y="${o.y}" ${F.attr} font-size="${s}"><tspan fill="${c}">${esc(txt[0])}</tspan><tspan fill="${c}" fill-opacity="0.42">${esc(txt.slice(1))}</tspan></text></g>`; }
    case "mark": { const k = eo(u / 0.3); const mk = col(w.fundo_marca || "destaque");
      return `<rect x="${o.x - 20}" y="${o.y - s * 0.82}" width="${(o.wd + 40) * k}" height="${s * 1.02}" rx="14" fill="${mk}"/>` + `<g opacity="${cl((u - 0.1) / 0.15)}">${T(o.x, o.y, c)}</g>`; }
    case "dots": { let r = ""; for (let i = 0; i < 3; i++) { const q = eb((u - 0.12 * i) / 0.3); if (q > 0) r += `<circle cx="${o.x + s * 0.2 + i * s * 0.44}" cy="${o.y - s * 0.09}" r="${s * 0.145 * q}" fill="${c}"/>`; } return r; }
    case "strike": case "strike2": { const p = eo(u / 0.35); op = cl(u / 0.1); blur = (1 - p) * 12; const k = eo((u - 0.35) / 0.35);
      const sk = col(w.cor_risco || (bl && bl.bg === "destaque" ? "fundo" : "texto"));
      extra = `<rect x="${o.x - 10}" y="${o.y - s * 0.36}" width="${(o.wd + 20) * k}" height="${s * 0.11}" rx="6" fill="${sk}"/>`;
      if (w.a === "strike2") { const k2 = eo((u - 0.55) / 0.35); extra += `<rect x="${o.x - 10}" y="${o.y - s * 0.2}" width="${(o.wd + 20) * k2}" height="${s * 0.09}" rx="6" fill="${sk}"/>`; }
      break; }
    case "type": { const n = Math.floor(cl(u / (w.dur || 0.04 * txt.length)) * txt.length); const caret = (Math.floor(u * 2.5) % 2 === 0) ? "▍" : "";
      txt = txt.slice(0, n) + (n < w.t.length || u < (w.dur || 0.04 * w.t.length) + 0.8 ? caret : ""); break; }
  }
  const f = blur > 0.3 ? `style="filter:blur(${blur.toFixed(1)}px)"` : "";
  return `<g opacity="${op.toFixed(3)}" ${f} transform="translate(${cx} ${cy + dy}) scale(${sc.toFixed(3)}) translate(${-cx} ${-cy})">${T(o.x, o.y, c)}${extra}</g>`;
}

// ---------- mídias ----------
function frameHref(m, t) {
  const n = m.n || 1, fps = m.fps || 30;
  let i = Math.round((t - (m.at || 0) + (m.offset || 0)) * fps) + 1;
  i = m.loop ? ((i - 1) % n + n) % n + 1 : Math.min(n, Math.max(1, i));
  return href(m.frames.replace(/\/$/, "") + "/f" + String(i).padStart(4, "0") + ".jpg");
}
function tag(x, y, txt, estilo) {
  const neutro = estilo === "neutro";
  const fill = neutro ? C.texto : C.destaque, cor = C.fundo;
  const w = rotW(txt, 28) + 60;
  x = Math.max(SAFE.x0 + w / 2, Math.min(SAFE.x1 - w / 2, x));
  return `<g><rect x="${x - w / 2}" y="${y - 28}" width="${w}" height="56" rx="28" fill="${fill}"/><text x="${x}" y="${y + 10}" text-anchor="middle" font-family="F_ROT" font-weight="${FT.rotulo.peso}" font-size="28" fill="${cor}">${esc(txt)}</text></g>`;
}
let _clip = 0;
function mediaDraw(bl, t) {
  let s = "";
  for (const m of (bl.midias || [])) {
    const at = m.at != null ? m.at : bl.a;
    const src = m.frames ? frameHref(Object.assign({ at }, m), t) : href(m.src);
    if (m.tipo === "fundo") {
      const op = m.fade ? cl((t - at) / m.fade) : 1;
      const bf = m.desfoque ? `style="filter:blur(${m.desfoque}px)"` : "";
      s += `<g opacity="${op.toFixed(3)}"><image href="${src}" x="0" y="0" width="1080" height="1920" preserveAspectRatio="xMidYMid slice" ${bf}/><rect width="1080" height="1920" fill="${C.fundo}" opacity="${m.escurecer != null ? m.escurecer : 0.55}"/></g>`;
    }
    if (m.tipo === "cartao") {
      if (t < at - 0.02) continue;
      const w = m.w || 420, h = m.h || 620, x = m.x || 540, y = m.y || 640, rot = m.rot || 0;
      const p = eb((t - at) / 0.5), op0 = cl((t - at + 0.05) / 0.2);
      const ring = col(m.borda || "destaque"), r = m.raio || 28, id = "c" + (_clip++);
      let fx = "", sc = p, op = op0, over = "";
      const e = m.efeito;
      if (e && e.tipo === "apagar") { const k = eio((t - e.at) / 0.8); if (k > 0) { fx = `style="filter:grayscale(${k.toFixed(2)}) blur(${(k * 3).toFixed(1)}px)"`; sc *= 1 - 0.12 * k; op *= 1 - 0.55 * k; } }
      if (e && e.tipo === "pixelar") { const k = cl((t - e.at) / 0.6); if (k > 0) { const cx = 14, cy = 8;
          for (let i = 0; i < cx; i++) for (let j = 0; j < cy; j++) if (((i * 7 + j * 13) % 10) / 10 < k * 0.6)
            over += `<rect x="${-w / 2 + i * w / cx}" y="${-h / 2 + j * h / cy}" width="${w / cx + 1}" height="${h / cy + 1}" fill="${(i + j) % 2 ? C.linha : C.card}" opacity="0.55"/>`; } }
      s += `<g opacity="${op.toFixed(3)}" ${fx} transform="translate(${x} ${y}) rotate(${rot}) scale(${Math.max(sc, 0.001).toFixed(3)})"><clipPath id="${id}"><rect x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" rx="${r}"/></clipPath><image href="${src}" x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid slice" clip-path="url(#${id})"/>${over}<rect x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" rx="${r}" fill="none" stroke="${ring}" stroke-width="${m.espessura || 6}"/></g>`;
    }
    const tg = m.tag || (m.tipo === "tag" ? m : null);
    if (tg && tg.texto) { const ta = tg.at != null ? tg.at : at + 0.35; if (t > ta) {
        let fade = 1; if (m.efeito && m.efeito.tipo === "apagar") fade = 1 - 0.5 * eio((t - m.efeito.at) / 0.8);
        s += `<g opacity="${(cl((t - ta) / 0.3) * fade).toFixed(3)}">${tag(tg.x || 540, tg.y || 370, tg.texto, tg.estilo)}</g>`; } }
  }
  return s;
}

// ---------- extras ----------
function findWord(L, txt) { return L.find(o => o.w.t === txt) || L.find(o => o.w.t.replace(/[.,!?:]/g, "") === String(txt).replace(/[.,!?:]/g, "")); }
function extras(bl, t, L) {
  let s = "";
  const onBg = bl.bg === "destaque" ? C.fundo : C.texto;
  for (const e of (bl.extras || [])) {
    switch (e.tipo) {
      case "checks": (e.palavras || []).forEach((w0, i) => { const o = findWord(L, w0); const tt = (e.at || [])[i] != null ? e.at[i] : (o ? o.w.at + 0.25 : 0); const p = eb((t - tt) / 0.35);
          if (p > 0 && o) s += `<g transform="translate(${Math.min(o.x + o.wd + 50, 1010)} ${o.y - o.s * 0.33}) scale(${p.toFixed(3)})"><circle r="34" fill="${C.destaque}"/><path d="M-15 0 L-4 12 L16 -12" fill="none" stroke="${C.fundo}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></g>`; }); break;
      case "selo": { const p = eb((t - e.at) / 0.4); if (p > 0) { const fs = e.tamanho || 56; cv.font = `800 ${fs}px F_IMP`; const w = cv.measureText(e.texto).width + 100; const cheio = e.estilo !== "contorno";
          const fill = cheio ? col(e.cor || (bl.bg === "destaque" ? "fundo" : "destaque")) : "none", tc = cheio ? (fill === C.fundo ? C.texto : C.fundo) : col(e.cor || "apoio");
          s += `<g transform="translate(${e.x || 540} ${e.y || 1400}) scale(${p.toFixed(3)})"><rect x="${-w / 2}" y="${-fs * 1.05}" width="${w}" height="${fs * 2.1}" rx="${fs * 1.05}" fill="${fill}" ${cheio ? "" : `stroke="${tc}" stroke-width="4"`}/><text x="0" y="${fs * 0.35}" text-anchor="middle" font-family="F_IMP" font-weight="800" font-size="${fs}" fill="${tc}">${esc(e.texto)}</text></g>`; } break; }
      case "linha_tempo": { const p = eo((t - e.at) / 0.6); if (p > 0) { const y = e.y || 1400, pts = e.pontos || [], x0 = 240, x1 = 840;
          s += `<rect x="${x0}" y="${y - 3}" width="${(x1 - x0) * p}" height="6" rx="3" fill="${C.rotulo}"/>`;
          pts.forEach((pt, i) => { const px = pts.length > 1 ? x0 + (x1 - x0) * i / (pts.length - 1) : 540; const q = eb((t - e.at - 0.5 * i) / 0.4); if (q <= 0) return; const last = i === pts.length - 1;
            s += `<circle cx="${px}" cy="${y}" r="${16 * q}" fill="${last ? C.destaque : onBg}"/><text x="${px}" y="${y + 70}" text-anchor="middle" font-family="F_ROT" font-weight="${FT.rotulo.peso}" font-size="38" fill="${last ? C.destaque : onBg}" opacity="${cl(q)}">${esc(pt)}</text>`; }); } break; }
      case "calendario": { const o = L.find(o => o.w.a === "count") || findWord(L, e.palavra); if (!o) break; const p = eb((t - o.w.at + 0.05) / 0.45); if (p > 0) {
          const w = 520, h = 410, x = 540 - w / 2, y = o.y - 340, cc = col(o.w.c), pin = bl.bg === "destaque" ? C.fundo : C.texto;
          s += `<g transform="translate(540 ${y + h / 2}) scale(${p.toFixed(3)}) translate(-540 ${-(y + h / 2)})"><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="40" fill="none" stroke="${cc}" stroke-width="8"/><rect x="${x}" y="${y}" width="${w}" height="70" rx="30" fill="${cc}"/><rect x="${x + 110}" y="${y - 30}" width="16" height="60" rx="8" fill="${pin}"/><rect x="${x + w - 126}" y="${y - 30}" width="16" height="60" rx="8" fill="${pin}"/></g>`; } break; }
      case "metade": { const o = findWord(L, e.palavra); if (!o) break; const p = eo((t - e.at) / 0.4); if (p > 0) { const x = o.x, y = o.y + 30, w = o.wd, sp = eio((t - e.at - 0.3) / 0.5);
          s += `<rect x="${x}" y="${y}" width="${w / 2 * p}" height="22" rx="11" fill="${C.destaque}"/><rect x="${x + w / 2 + 14 * sp}" y="${y + 40 * sp}" width="${w / 2 * p}" height="22" rx="11" fill="${C.linha}" opacity="${1 - 0.3 * sp}"/>`; } break; }
      case "brilho": { const o = findWord(L, e.palavra); if (!o) break; const p = eb((t - e.at) / 0.4); if (p > 0) { const x = Math.min(o.x + o.wd + 20, 1000), y = o.y - o.s * 0.9, r = 46 * p, rot = (t - e.at) * 90;
          s += `<g transform="translate(${x} ${y}) rotate(${rot})"><path d="M0 ${-r} Q${r * .18} ${-r * .18} ${r} 0 Q${r * .18} ${r * .18} 0 ${r} Q${-r * .18} ${r * .18} ${-r} 0 Q${-r * .18} ${-r * .18} 0 ${-r}Z" fill="${col(e.cor || "texto")}"/></g>`; } break; }
      case "icone": { if (e.ate != null && t > e.ate) break; const p = cl((t - e.at) / 0.3); if (p <= 0) break; const ic = { rewind: "M-70 0 L0 -50 L0 50 Z M10 0 L80 -50 L80 50 Z", play: "M-40 -55 L60 0 L-40 55 Z", seta: "M-70 -12 H30 V-45 L80 0 L30 45 V12 H-70 Z" }[e.nome] || "";
          s += `<g opacity="${p}" transform="translate(${e.x || 540} ${e.y || 520})${e.nome === "rewind" ? " scale(-1 1)" : ""}"><path d="${ic}" fill="${col(e.cor || "rotulo")}"/></g>`; break; }
      case "codigo": { const u = t - e.at; if (u < 0) break; const txt = e.texto, n = Math.floor(cl(u / (e.dur || 0.04 * txt.length)) * txt.length);
          const fs = e.tamanho || 38; cv.font = `400 ${fs}px F_COD`; const w = Math.min(900, cv.measureText(txt).width + 70); const p = eb(u / 0.35);
          s += `<g transform="translate(540 ${e.y || 1420}) scale(${p.toFixed(3)})"><rect x="${-w / 2}" y="-44" width="${w}" height="88" rx="18" fill="${C.card}" stroke="${C.linha}" stroke-width="3"/><text x="${-w / 2 + 35}" y="13" font-family="F_COD" font-size="${fs}" fill="${C.destaque}">${esc(txt.slice(0, n))}${(Math.floor(u * 2.5) % 2 === 0) ? "▍" : ""}</text></g>`; break; }
      case "onda": { if (t < e.at || (e.ate && t > e.ate + 0.3)) break; const p = eo((t - e.at) / 0.4), out = e.ate ? 1 - cl((t - e.ate) / 0.3) : 1; const n = 48, y = e.y || 1400, amps = e.amps;
          let g = ""; for (let i = 0; i < n; i++) { const a = amps ? amps[Math.floor(i * amps.length / n)] : (0.35 + 0.65 * Math.abs(Math.sin(i * 1.7 + t * 9) * Math.sin(i * 0.37 + t * 3.1))); const h = Math.max(8, 160 * a * p * out);
            g += `<rect x="${150 + i * 16}" y="${y - h / 2}" width="9" height="${h}" rx="4.5" fill="${i / n < (t - e.at) / ((e.ate || e.at + 3) - e.at) ? C.destaque : C.rotulo}"/>`; } s += g; break; }
      case "imagem": { const p = eb((t - e.at) / 0.45); if (p <= 0) break; const w = e.w || 300, h = e.h || 300;
          s += `<g opacity="${cl((t - e.at) / 0.15)}" transform="translate(${e.x || 540} ${e.y || 1400}) rotate(${e.rot || 0}) scale(${p.toFixed(3)})"><image href="${href(e.src)}" x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet"/></g>`; break; }
    }
  }
  if (bl.passo) { const st = bl.passo, p = eo((t - (st.at != null ? st.at : bl.a)) / 0.4); if (p > 0) {
      const c1 = bl.bg === "destaque" ? C.fundo : C.destaque, c2 = bl.bg === "destaque" ? C.fundo : C.apoio;
      s += `<g opacity="${p}" transform="translate(0 ${30 * (1 - p)})"><text x="90" y="${st.y || 470}" font-family="F_IMP" font-weight="800" font-size="150" fill="${c1}">${esc(st.n)}</text><text x="${90 + (String(st.n).length * 92) + 30}" y="${(st.y || 470) - 18}" font-family="F_ROT" font-weight="${FT.rotulo.peso}" font-size="34" letter-spacing="6" fill="${c2}">${esc(st.rotulo || "")}</text></g>`; } }
  return s;
}

// ---------- quadro ----------
function curBlock(t) { const bs = V.blocos.filter(b => t >= b.a); return bs[bs.length - 1] || V.blocos[0]; }
function draw(t) {
  _clip = 0;
  let s = "", bg = C.fundo;
  for (const bl of V.blocos) {
    if (t < bl.a) continue;
    const bc = col(bl.bg);
    if (bl.wipe) { const wp = Array.isArray(bl.wipe) ? bl.wipe : [540, 900]; const p = eio((t - bl.a + 0.08) / 0.42);
      if (p < 1) { s = `<rect width="1080" height="1920" fill="${bg}"/><circle cx="${wp[0]}" cy="${wp[1]}" r="${1300 * p}" fill="${bc}"/>`; bg = null; continue; } }
    bg = bc; s = "";
  }
  if (bg) s = `<rect width="1080" height="1920" fill="${bg}"/>`;
  for (const bl of V.blocos) {
    if (t < bl.a - 0.05 || t > bl.b + 0.01) continue;
    const L = layout(bl);
    const out = bl.sem_saida ? 1 : cl((bl.b - t) / 0.18), ob = (1 - out) * 14;
    let g = mediaDraw(bl, t); L.forEach(o => g += word(o, t, bl)); g += extras(bl, t, L);
    s += `<g opacity="${out.toFixed(3)}" ${ob > 0.3 ? `style="filter:blur(${ob.toFixed(1)}px)"` : ""}>${g}</g>`;
  }
  // cabeçalho por último (fica acima de fundos em vídeo)
  const h = V.cabecalho === false ? null : (V.cabecalho || {});
  if (h && t < DUR - 0.15) {
    const dark = curBlock(t).bg !== "destaque";
    const serie = h.serie || V.serie || (BR.series || [""])[0] || "", tema = h.tema || V.tema || "";
    const pr = cl(t / DUR);
    s += `<text x="90" y="215" font-family="F_ROT" font-weight="${FT.rotulo.peso}" font-size="30" letter-spacing="6" fill="${dark ? C.destaque : C.fundo}">${esc(serie)}</text><text x="990" y="215" text-anchor="end" font-family="F_ROT" font-weight="${FT.rotulo.peso}" font-size="30" fill="${dark ? C.rotulo : C.fundo}">${esc(tema)}</text>`;
    if (h.barra !== false) s += `<rect x="90" y="245" width="900" height="6" rx="3" fill="${dark ? C.linha : "rgba(0,0,0,.18)"}"/><rect x="90" y="245" width="${(900 * pr).toFixed(1)}" height="6" rx="3" fill="${dark ? C.destaque : C.fundo}"/>`;
  }
  document.getElementById("s").innerHTML = s;
}

// ---------- assinatura (vinheta final, 3,2s) ----------
function drawSig(u) {
  const A = BR.assinatura || {}, logo = BR.logo || {};
  const up = eio((u - 1.25) / 0.55) * 150;
  let s = `<rect width="1080" height="1920" fill="${C.fundo}"/>`;
  const L = A.tamanho_logo || 400, lx = 540 - L / 2, ly = 760 - L / 2;
  const fin = [-0.07, -0.035, 0, 0].map(v => v * L * (A.fatiado === false ? 0 : 1)), st = [1.3, -1.6, 1.9, -1.2].map(v => v * L), dl = [0.10, 0, 0.16, 0.06];
  if (logo.arquivo) {
    const src = logo.arquivo.startsWith("/") ? "file://" + logo.arquivo : "file://" + MARCA_DIR + "/" + logo.arquivo;
    s += "<defs>" + [0, 1, 2, 3].map(i => `<clipPath id="sg${i}"><rect x="-3000" y="${ly + i * L / 4}" width="7000" height="${L / 4 + (i < 3 ? 0.5 : 0)}"/></clipPath>`).join("") + "</defs>";
    s += `<g transform="translate(0 ${-up})">`;
    for (let i = 0; i < 4; i++) { const p = eb((u - dl[i]) / 0.55); const x = st[i] + (fin[i] - st[i]) * p;
      s += `<g clip-path="url(#sg${i})"><image href="${src}" x="${(lx + x).toFixed(1)}" y="${ly}" width="${L}" height="${L}" opacity="${eo((u - dl[i]) / 0.15).toFixed(3)}" preserveAspectRatio="xMidYMid meet"/></g>`; }
    if (A.fatiado !== false) for (let i = 1; i < 4; i++) s += `<rect x="0" y="${ly + i * L / 4 - 5}" width="1080" height="10" fill="${C.fundo}"/>`;
    s += "</g>";
  }
  const p = eo((u - 0.62) / 0.45);
  const wm = A.marca_texto || [[BR.nome || "", "texto"]];
  s += `<g opacity="${p.toFixed(3)}" transform="translate(0 ${(40 * (1 - p) - up).toFixed(1)})" text-anchor="middle">` + wm.map((ln, i) => `<text x="540" y="${1105 + i * 90}" font-family="F_IMP" font-weight="${FT.impacto.peso}" font-size="${A.tamanho_texto || 96}" fill="${col(ln[1] || "texto")}">${esc(ln[0])}</text>`).join("") + "</g>";
  const baseY = 1105 + (wm.length - 1) * 90 - 150 + 125;
  const items = [];
  if (A.chamada) items.push([1.45, `<text x="540" y="${baseY}" text-anchor="middle" font-family="F_LIG" font-weight="${FT.ligacao.peso}" ${FT.ligacao.italico ? 'font-style="italic"' : ""} font-size="58" fill="${C.apoio}">${esc(A.chamada)}</text>`]);
  (A.perfis || []).forEach((pf, i) => { const y = baseY + 110 + i * 165;
    items.push([1.65 + 0.2 * i, `<g><text x="540" y="${y}" text-anchor="middle" font-family="F_ROT" font-size="40" fill="${C.apoio}" letter-spacing="3">${esc(pf[0])}</text><text x="540" y="${y + 70}" text-anchor="middle" font-family="F_IMP" font-weight="${FT.impacto.peso}" font-size="68" fill="${col(pf[2] || (i === (A.perfis.length - 1) ? "destaque" : "texto"))}">${esc(pf[1])}</text></g>`]); });
  for (const [t0, h] of items) { const q = eo((u - t0) / 0.45); if (q <= 0) continue;
    s += `<g opacity="${q.toFixed(3)}" transform="translate(0 ${(50 * (1 - q)).toFixed(1)})" ${q < 0.9 ? `style="filter:blur(${((1 - q) * 10).toFixed(1)}px)"` : ""}>${h}</g>`; }
  document.getElementById("s").innerHTML = s;
}

// ---------- revisão automática ----------
function lint() {
  const issues = [], warn = (b, m) => issues.push({ bloco: b, msg: m });
  const Bs = V.blocos;
  if (!DUR) warn("-", "video.duracao ausente");
  Bs.forEach((bl, i) => {
    const id = `#${i + 1} (${bl.a}-${bl.b}s)`;
    if (bl.b <= bl.a) warn(id, "b menor ou igual a a");
    if (i > 0 && Math.abs(Bs[i - 1].b - bl.a) > 0.05) warn(id, `buraco/sobreposição com o bloco anterior (${Bs[i - 1].b} → ${bl.a})`);
    const L = layout(bl), bgc = col(bl.bg);
    let nWords = 0;
    L.forEach(o => {
      const w = o.w; nWords++;
      if (w.at < bl.a - 0.05 || w.at > bl.b) warn(id, `"${w.t}" entra em ${w.at}s, fora do bloco`);
      else if (bl.b - w.at < 0.3) warn(id, `"${w.t}" fica só ${(bl.b - w.at).toFixed(2)}s na tela`);
      const top = o.y - o.s * 0.82, bot = o.y + o.s * 0.22;
      if (o.x < SAFE.x0 - 1 || o.x + o.wd > SAFE.x1 + 1) warn(id, `"${w.t}" sai da largura segura (x ${o.x.toFixed(0)}–${(o.x + o.wd).toFixed(0)})`);
      if (top < SAFE.y0 + 20 || bot > SAFE.y1) warn(id, `"${w.t}" sai da altura segura (y ${top.toFixed(0)}–${bot.toFixed(0)})`);
      if (col(w.c).toLowerCase() === bgc.toLowerCase()) warn(id, `"${w.t}" tem a mesma cor do fundo`);
      if (o.fit < 0.9 && o === L.find(q => q.line === o.line)) warn(id, `linha ${o.line + 1} reduzida para ${(o.fit * 100).toFixed(0)}% (cabe, mas confira a hierarquia)`);
    });
    if (nWords > 14) warn(id, `${nWords} palavras na tela: acima de ~12 fica difícil ler`);
    for (const m of (bl.midias || [])) if (m.tipo === "cartao") {
      const x = m.x || 540, y = m.y || 640, w = m.w || 420, h = m.h || 620;
      if (x - w / 2 < 40 || x + w / 2 > 1040 || y - h / 2 < 270 || y + h / 2 > 1560) warn(id, `cartão ${m.src || m.frames} encosta na borda/área da interface`);
      L.forEach(o => { const top = o.y - o.s * 0.82, bot = o.y + o.s * 0.22; if (o.x < x + w / 2 && o.x + o.wd > x - w / 2 && top < y + h / 2 && bot > y - h / 2) warn(id, `"${o.w.t}" sobrepõe o cartão ${m.src || m.frames}`); });
    }
  });
  const last = Bs[Bs.length - 1]; if (last && DUR && Math.abs(last.b - DUR) > 0.1) warn("fim", `último bloco termina em ${last.b}s, mas a duração é ${DUR}s`);
  return { issues, fontErr: window.__fontErr || [] };
}
window.setup = setup; window.draw = draw; window.drawSig = drawSig; window.lint = lint;
