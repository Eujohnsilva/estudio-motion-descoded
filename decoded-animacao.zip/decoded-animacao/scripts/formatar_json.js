// formata video.json: uma palavra por linha, compacto
const fs=require('fs');const f=process.argv[2];
let v=JSON.parse(fs.readFileSync(f,'utf8').replace(/,,/g,','));
const J=x=>JSON.stringify(x);
let s='{\n'+Object.entries(v).filter(([k])=>k!=='blocos').map(([k,x])=>` ${J(k)}: ${J(x)}`).join(',\n')+',\n "blocos": [\n';
s+=v.blocos.map(b=>{const {linhas,...r}=b;let o='  {'+Object.entries(r).map(([k,x])=>`${J(k)}:${J(x)}`).join(', ')+',\n   "linhas": [\n';
 o+=linhas.map(l=>'    ['+l.map(w=>J(w)).join(',\n     ')+']').join(',\n')+'\n   ]}';return o;}).join(',\n');
s+='\n ]\n}\n';fs.writeFileSync(f,s);
