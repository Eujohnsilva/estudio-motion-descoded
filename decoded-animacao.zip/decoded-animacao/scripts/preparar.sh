#!/usr/bin/env bash
# Confere (e instala, se faltar) o que o motor precisa. Rode uma vez por conversa, antes do primeiro render.
ok(){ echo "✓ $1"; }; falta(){ echo "✗ $1"; }
command -v ffmpeg >/dev/null && ok ffmpeg || { falta ffmpeg; (apt-get install -y ffmpeg >/dev/null 2>&1 || pip install --break-system-packages imageio-ffmpeg >/dev/null 2>&1) && echo "  instalado"; }
command -v node >/dev/null && ok "node $(node -v)" || falta "node (necessário para o render)"
if ! node -e "require('playwright')" 2>/dev/null; then
  export NODE_PATH="$(npm root -g):$NODE_PATH"
  node -e "require('playwright')" 2>/dev/null || { echo "  instalando playwright..."; npm i -g playwright >/dev/null 2>&1; export NODE_PATH="$(npm root -g)"; }
fi
node -e "require('playwright')" 2>/dev/null && ok playwright || falta playwright
node -e "const {chromium}=require('playwright');chromium.launch().then(b=>{b.close();console.log('✓ chromium')}).catch(()=>{console.log('✗ chromium');process.exit(1)})" 2>/dev/null || { npx playwright install chromium >/dev/null 2>&1 && echo "  chromium instalado"; }
python3 -c "import numpy, PIL" 2>/dev/null && ok "numpy + Pillow" || { pip install --break-system-packages numpy pillow >/dev/null 2>&1 && echo "  numpy/Pillow instalados"; }
echo "NODE_PATH=$NODE_PATH   (exporte esta variável se o render reclamar de 'playwright')"
