# Configuração da marca (primeira vez)

Objetivo: sair daqui com uma skill pessoal `decoded-marca` instalada na conta do criador, contendo `brand.json`, `voice.md`, `about-me.md` e o logo. Depois disso, todas as skills do pacote encontram a marca sozinhas, em qualquer conversa.

Conduza como um diretor de arte e um editor sênior conduziriam uma reunião de kickoff: perguntas curtas, uma rodada por vez, propondo em vez de só perguntar. Use a ferramenta de perguntas de múltipla escolha quando houver.

## Rodada 1 · Quem é a marca (about-me.md)
Pergunte em uma mensagem:
1. Nome do perfil e @ (e do autor, se for diferente).
2. Sobre o que é o perfil, em uma frase.
3. Quem assiste: o que essa pessoa sabe e o que ela quer.
4. De 2 a 4 pilares de conteúdo.
5. O que a marca promete (ex.: "tudo checado", "direto ao ponto", "com humor").
6. O que fica de fora (temas, tons, a vida pessoal, política partidária...).
7. Os nomes das séries, se já existem (ex.: "DECODIFICADO", "MITO OU FATO"). Se não existem, proponha 3 a partir dos pilares.

## Rodada 2 · Como a marca fala (voice.md)
Peça de 3 a 5 textos que o criador escreveu ou falou: roteiros, legendas, posts, transcrições de vídeo. Explique que é isso que faz o roteiro soar como ele e não como uma IA.

Analise e escreva o `voice.md` com as seções do modelo `assets/modelos/voice.md`: como soa, tom, ritmo, estrutura narrativa, ganchos, como abre, como fecha, expressões recorrentes, o que nunca faz. **Cada afirmação precisa vir dos textos** (cite a contagem, ex.: "reticências em 4 de 5 textos"). Se não houver textos, monte uma voz provisória a partir das respostas e marque como provisória.

Duas regras do pacote que entram em toda voz, salvo pedido contrário: sem travessão no texto falado (trocar por ponto ou reticências) e sem emoji ou hashtag na narração.

## Rodada 3 · Como a marca aparece (brand.json)
Se o criador já tem identidade (paleta, fontes, logo), peça os arquivos e transcreva. Se não tem, peça referências visuais primeiro (perfis, marcas, cores de que gosta) e então **proponha** em vez de perguntar no vazio: 2 direções curtas, cada uma com paleta de 3 cores, par de fontes e o porquê em uma linha, construídas a partir das respostas dele e das referências. Nenhuma das direções pode ser a paleta do Motion Decoded (preto + lima). Depois da escolha, ajuste.

### Cores (papéis, não gosto pessoal)
| Papel | Uso | Regra |
|---|---|---|
| `fundo` | fundo da maioria das telas | escuro ou muito claro, nunca saturado |
| `texto` | texto principal | contraste ≥ 7:1 com `fundo` |
| `destaque` | palavras-chave, picos, wipes | contraste ≥ 3:1 com `fundo` **e** `fundo` legível sobre ele (o motor inverte nos blocos de destaque) |
| `apoio` | palavras de ligação | contraste ≥ 4,5:1 com `fundo`, visivelmente mais apagado que `texto` |
| `rotulo` | cabeçalho, tags secundárias | contraste ≥ 3:1 |
| `card`, `linha` | cartões e divisórias | 1 a 2 tons acima do `fundo` |

O `criar_marca.py` mede todos os contrastes e reprova o que não passar. Destaque deve ser **raro** no vídeo: 3 a 4 momentos de fundo `destaque` por vídeo.

### Fontes (três papéis)
- `impacto`: palavras-chave grandes. Sem serifa, peso 700 a 900, desenho largo o bastante para ser lida em 120 a 300 px.
- `ligacao`: palavras pequenas entre as palavras-chave. Contraste de estilo com o impacto (serifa itálica, ou o mesmo sans em peso leve).
- `rotulo`: cabeçalho, tags e selos. Sans em peso médio, em caixa alta com espaçamento.

Use fontes do sistema (liste com `fc-list : family | sort -u`) ou arquivos `.ttf`/`.otf` que o criador enviar e tenha licença para usar. Fontes enviadas vão para a pasta da marca e são referenciadas pelo nome do arquivo. Fontes com licença OFL (Google Fonts) podem ser usadas livremente.

### Logo
SVG ou PNG com fundo transparente, só o símbolo (sem o nome), quadrado ou quase. O motor fatia o logo em 4 faixas na vinheta final.

**Se o criador já tem logo:** peça o arquivo e use como está.

**Se não tem:** antes de desenhar qualquer coisa, peça referências em uma mensagem: "Tem algum logo, marca ou perfil cujo estilo você curte? Pode ser de qualquer área." Depois gere opções com as iniciais e a marca **dele**:
```bash
python3 <pasta-desta-skill>/scripts/monograma.py --iniciais AB --marca marca/brand.json --saida opcoes/
```
Saem 6 estruturas diferentes (letra solta, selo circular, contorno, bloco, assinatura, par de letras) em `opcoes/opcoes.png`. Mostre a prancha, peça para escolher uma e ajuste a partir dela. Com referência, adapte a estrutura escolhida ao que a referência ensina (peso, forma do contêiner, uso de cor). Para testar outras fontes, passe `--fonte /caminho/da/fonte.otf` (até duas).

**Regra de originalidade:** o logo e a identidade do comprador **nunca** derivam da marca Motion Decoded nem de outra marca existente. Os arquivos do Motion Decoded neste pacote (vídeo 5, capas reais, voz de exemplo, valores do `schema-brand.md`) são **exemplos de nível de qualidade**, não ponto de partida visual. Não use o M geométrico, a paleta preta e lima nem as faixas horizontais como base, a menos que o próprio criador peça uma direção parecida, e mesmo assim mude a forma. Sem referência, a direção vem das respostas da Rodada 1 (tom, público, promessa): explique em uma linha por que cada opção combina com a marca dele.

Diga que o logo é provisório até o criador validar com quem cuida da identidade dele.

### Assinatura (vinheta de 3,2 s no fim do vídeo)
- `marca_texto`: o nome em 1 ou 2 linhas, com a cor de cada linha.
- `chamada`: frase curta ("Siga nossos perfis").
- `perfis`: até 3 linhas de [rótulo, @]. O último fica em destaque.

## Rodada 4 · Gerar, conferir e instalar
1. Monte a pasta de trabalho `marca/` com `brand.json`, `voice.md`, `about-me.md`, o logo e as fontes enviadas.
2. Rode:
   ```bash
   python3 <pasta-desta-skill>/scripts/criar_marca.py marca/
   ```
   Ele valida os campos, mede os contrastes, renderiza uma prévia (duas telas de vídeo, a vinheta e uma capa de exemplo) e gera `decoded-marca.zip`.
3. Mostre a prévia ao criador. Ajuste até ele aprovar.
4. Entregue o `decoded-marca.zip` com a instrução de instalação:
   > Em Configurações → Recursos (ou Personalizar → Skills), confirme que "Execução de código e criação de arquivos" está ativo, clique em "Enviar skill" e selecione `decoded-marca.zip`. Depois disso, qualquer conversa nova já conhece a sua marca.
5. Para mudar algo depois (cor, @, voz), basta pedir: edite os arquivos, rode o `criar_marca.py` de novo e reenvie o ZIP, substituindo a skill antiga.

## Alternativa sem instalar a skill
Se o criador usa um Projeto, os arquivos da pasta `marca/` podem ir para o conhecimento do Projeto. As skills procuram `brand.json` também em `/mnt/project` e nos anexos da conversa.
