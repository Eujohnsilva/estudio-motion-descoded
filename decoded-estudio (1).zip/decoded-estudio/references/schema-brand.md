# brand.json · todos os campos

Os valores abaixo são os da marca Motion Decoded e servem só para mostrar o formato. Não os use como ponto de partida para outra marca.

```json
{
  "nome": "Motion Decoded",
  "perfil": "@motiondescoded",
  "cores": {
    "fundo": "#0A0A0A", "texto": "#F2F2EC", "destaque": "#C8FF2E",
    "apoio": "#A9A9A2", "rotulo": "#7C7C76", "card": "#151515", "linha": "#2A2A2A",
    "glitch": ["#FF3B6B", "#3BD8FF"]
  },
  "fontes": {
    "impacto": {"arquivo": "/usr/share/fonts/opentype/inter/InterDisplay-ExtraBold.otf", "peso": 800},
    "ligacao": {"arquivo": "/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf", "peso": 500, "italico": true},
    "rotulo":  {"arquivo": "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", "peso": 600},
    "codigo":  {"arquivo": "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", "peso": 400}
  },
  "logo": {"arquivo": "logo.svg"},
  "series": ["DECODIFICADO", "NOTÍCIA EM 15S", "MITO OU FATO", "BASTIDORES"],
  "assinatura": {
    "marca_texto": [["motion", "texto"], ["decoded", "destaque"]],
    "chamada": "Siga nossos perfis",
    "perfis": [["AUTOR", "@talvezrelevante"], ["PRODUÇÃO", "@motiondescoded"]],
    "fatiado": true
  },
  "voz": {"palavras_por_segundo": 2.0, "fechamento": "Mas e aí…"},
  "pronuncia": {"claude": "clód", "after": "áfter"},
  "plataformas": ["instagram", "tiktok", "youtube", "linkedin"]
}
```

| Campo | Obrigatório | Notas |
|---|---|---|
| `nome` | sim | usado na assinatura quando `marca_texto` não existe |
| `cores.fundo/texto/destaque` | sim | as demais têm padrão, mas defina todas para controle |
| `fontes.<papel>.arquivo` | não | caminho absoluto ou relativo à pasta da marca. Alternativa: `"familia": "Nome da fonte instalada"` |
| `fontes.<papel>.peso` / `italico` / `tracking` | não | `tracking` em px por letra (ex.: -4 para títulos fechados) |
| `logo.arquivo` | recomendado | SVG ou PNG transparente, relativo à pasta da marca |
| `series` | recomendado | o primeiro é o padrão do cabeçalho |
| `assinatura.fatiado` | não | `false` desliga as faixas do logo na vinheta |
| `voz.palavras_por_segundo` | recomendado | medido na primeira narração real; o roteiro usa para estimar duração |
| `pronuncia` | não | ajuda o alinhamento com palavras estrangeiras: `"palavra": "como se fala"` |
| `plataformas` | não | quais legendas gerar por padrão |

Nos arquivos de vídeo e capa, as cores são usadas **pelo papel** (`"destaque"`, `"apoio"`...), nunca pelo código hex. Assim, trocar a paleta da marca atualiza tudo.
