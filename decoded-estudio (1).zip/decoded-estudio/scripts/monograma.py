# Gera opções de monograma (logo provisório) a partir das iniciais e da marca do criador.
# As letras viram contorno (path), então o SVG funciona em qualquer lugar sem depender de fonte.
# Uso: python3 monograma.py --iniciais AB --marca brand.json --saida opcoes/ [--fonte /caminho/fonte.otf ...]
# Saídas: opcoes/opcao-1.svg ... opcao-6.svg e opcoes/opcoes.png (prancha para mostrar ao criador)
import os, json, argparse, subprocess
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen
ap = argparse.ArgumentParser(); ap.add_argument('--iniciais', required=True); ap.add_argument('--marca', required=True)
ap.add_argument('--saida', default='opcoes'); ap.add_argument('--fonte', action='append', default=[]); A = ap.parse_args()
B = json.load(open(A.marca, encoding='utf-8')); bdir = os.path.dirname(os.path.abspath(A.marca)); C = B.get('cores', {})
FUNDO, TEXTO, DEST = C.get('fundo', '#111111'), C.get('texto', '#F5F5F5'), C.get('destaque', '#FFB020')
def fpath(r, d):
    f = (B.get('fontes') or {}).get(r, {}); a = f.get('arquivo')
    if a: return a if a.startswith('/') else os.path.join(bdir, a)
    if f.get('familia'):
        p = subprocess.run(['fc-match', '-f', '%{file}', f['familia']], capture_output=True, text=True).stdout.strip()
        if p: return p
    return d
fontes = A.fonte or [fpath('impacto', '/usr/share/fonts/opentype/inter/InterDisplay-ExtraBold.otf'), fpath('ligacao', '/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf')]
def glyphs(txt, font, size, track=0):
    """devolve (path d, largura, altura) do texto em contorno, com origem no canto superior esquerdo do desenho"""
    F = TTFont(font); gs = F.getGlyphSet(); cmap = F.getBestCmap(); upm = F['head'].unitsPerEm; s = size / upm
    parts, x, xmin, xmax, ymin, ymax = [], 0, 1e9, -1e9, 1e9, -1e9
    for ch in txt:
        g = cmap.get(ord(ch));
        if not g: continue
        bp = BoundsPen(gs); gs[g].draw(bp)
        if bp.bounds:
            a, b, c, d = bp.bounds; xmin = min(xmin, x + a); xmax = max(xmax, x + c); ymin = min(ymin, b); ymax = max(ymax, d)
        pen = SVGPathPen(gs); gs[g].draw(pen); parts.append((x, pen.getCommands())); x += gs[g].width + track * upm / size
    out = ''.join(f'<path transform="translate({(px - xmin) * s:.2f} {ymax * s:.2f}) scale({s:.5f} {-s:.5f})" d="{d}"/>' for px, d in parts)
    return out, (xmax - xmin) * s, (ymax - ymin) * s
os.makedirs(A.saida, exist_ok=True)
I = A.iniciais.strip(); i1 = I[0]
f1 = fontes[0]; f2 = fontes[1] if len(fontes) > 1 else fontes[0]
def center(inner, w, h, cx=200, cy=200): return f'<g transform="translate({cx - w / 2:.1f} {cy - h / 2:.1f})">{inner}</g>'
ops = []
g, w, h = glyphs(I, f1, 230 if len(I) > 1 else 300, -0.02)
k = min(1, 300 / max(w, 1)); g, w, h = glyphs(I, f1, (230 if len(I) > 1 else 300) * k, -0.02)
ops.append(('Letra solta', f'<g fill="{DEST}">{center(g, w, h)}</g>'))
g, w, h = glyphs(I, f1, 170 if len(I) > 1 else 210)
ops.append(('Selo circular', f'<circle cx="200" cy="200" r="186" fill="{DEST}"/><g fill="{FUNDO}">{center(g, w, h)}</g>'))
ops.append(('Contorno', f'<circle cx="200" cy="200" r="176" fill="none" stroke="{DEST}" stroke-width="20"/><g fill="{TEXTO}">{center(g, w, h)}</g>'))
g, w, h = glyphs(I, f1, 180 if len(I) > 1 else 220)
ops.append(('Bloco', f'<rect x="14" y="14" width="372" height="372" rx="72" fill="{TEXTO}"/><g fill="{FUNDO}">{center(g, w, h)}</g>'))
g, w, h = glyphs(i1, f2, 300)
ops.append(('Assinatura', f'<g fill="{DEST}">{center(g, w, h, 190, 200)}</g><circle cx="{min(370, 190 + w / 2 + 28):.0f}" cy="{200 + h / 2 - 20:.0f}" r="22" fill="{TEXTO}"/>'))
if len(I) > 1:
    ga, wa, ha = glyphs(I[0], f1, 260); gb, wb, hb = glyphs(I[1], f2, 230)
    ops.append(('Par de letras', f'<g fill="{TEXTO}">{center(ga, wa, ha, 160, 190)}</g><g fill="{DEST}">{center(gb, wb, hb, 250, 215)}</g>'))
else:
    g, w, h = glyphs(i1, f1, 230)
    ops.append(('Canto', f'<path d="M14 14 H300 L386 100 V386 H14 Z" fill="{DEST}"/><g fill="{FUNDO}">{center(g, w, h)}</g>'))
html = '<html><body style="margin:0;background:#1c1c1c;font:600 18px sans-serif;color:#ddd"><div style="display:flex;flex-wrap:wrap;gap:20px;padding:20px;width:1340px">'
for n, (nome, inner) in enumerate(ops, 1):
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">{inner}</svg>'
    open(os.path.join(A.saida, f'opcao-{n}.svg'), 'w').write(svg)
    html += f'<div><div style="background:{FUNDO};width:420px;height:420px;display:flex;align-items:center;justify-content:center">{svg.replace("width=\"400\" height=\"400\"", "width=\"300\" height=\"300\"")}</div><div style="padding:8px 2px">{n}. {nome}</div></div>'
html += '</div></body></html>'
hp = os.path.abspath(os.path.join(A.saida, '_prancha.html')); open(hp, 'w').write(html)
png = os.path.abspath(os.path.join(A.saida, 'opcoes.png'))
js = f"""let PW;try{{PW=require('playwright')}}catch(e){{for(const r of [require('child_process').execSync('npm root -g').toString().trim(),'/usr/local/lib/node_modules_global','/opt/npm-tools/node_modules']){{try{{PW=require(r+'/playwright');break}}catch(_){{}}}}}}
(async()=>{{const b=await PW.chromium.launch();const p=await b.newPage({{viewport:{{width:1380,height:960}}}});await p.goto('file://{hp}');await p.screenshot({{path:'{png}',fullPage:true}});await b.close();}})();"""
subprocess.run(['node', '-e', js], check=True); os.remove(hp)
print('ok:', png, '·', len(ops), 'opções em', A.saida)
