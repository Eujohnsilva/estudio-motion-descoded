# Valida a marca, mede contrastes, gera a prévia visual e empacota a skill pessoal decoded-marca.
# Uso: python3 criar_marca.py PASTA_DA_MARCA [--saida DIR] [--sem-previa]
# A pasta precisa ter brand.json; voice.md, about-me.md, logo e fontes são copiados se existirem.
import sys, os, json, shutil, zipfile, subprocess, argparse, re
ap = argparse.ArgumentParser(); ap.add_argument('pasta'); ap.add_argument('--saida', default=None); ap.add_argument('--sem-previa', action='store_true'); A = ap.parse_args()
P = os.path.abspath(A.pasta); OUT = os.path.abspath(A.saida or ('/mnt/user-data/outputs' if os.path.isdir('/mnt/user-data/outputs') else '.'))
B = json.load(open(os.path.join(P, 'brand.json'), encoding='utf-8'))
erros, avisos = [], []
def hexrgb(h):
    h = h.lstrip('#'); h = ''.join(c * 2 for c in h) if len(h) == 3 else h; return [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
def lum(h):
    r = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in hexrgb(h)]; return 0.2126 * r[0] + 0.7152 * r[1] + 0.0722 * r[2]
def cr(a, b): la, lb = sorted([lum(a), lum(b)], reverse=True); return (la + 0.05) / (lb + 0.05)
C = B.get('cores', {})
for k in ('fundo', 'texto', 'destaque'):
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', str(C.get(k, ''))): erros.append(f'cores.{k} ausente ou inválida (use #RRGGBB)')
if not erros:
    C.setdefault('apoio', '#A9A9A2'); C.setdefault('rotulo', '#7C7C76')
    for a, b, mn, nome, grave in [('texto', 'fundo', 7, 'texto sobre fundo', True), ('destaque', 'fundo', 3, 'destaque sobre fundo', True), ('fundo', 'destaque', 4.5, 'fundo sobre destaque (blocos invertidos)', True),
                                  ('apoio', 'fundo', 4.5, 'apoio sobre fundo', False), ('rotulo', 'fundo', 3, 'rótulo sobre fundo', False)]:
        v = cr(C[a], C[b]); msg = f'contraste {nome}: {v:.1f}:1 (mínimo {mn}:1)'
        if v < mn: (erros if grave else avisos).append(msg)
        else: print('✓', msg)
    if cr(C['apoio'], C['fundo']) > cr(C['texto'], C['fundo']) * 0.92: avisos.append('apoio quase igual ao texto: a hierarquia entre ligação e palavra-chave some')
for r, f in (B.get('fontes') or {}).items():
    a = f.get('arquivo')
    if a and not os.path.exists(a if a.startswith('/') else os.path.join(P, a)): erros.append(f'fonte {r}: arquivo não encontrado ({a})')
    if f.get('familia') and not a:
        if not subprocess.run(['fc-list', f':family={f["familia"]}'], capture_output=True, text=True).stdout.strip(): erros.append(f'fonte {r}: família "{f["familia"]}" não instalada')
lg = (B.get('logo') or {}).get('arquivo')
if not lg: avisos.append('sem logo: a vinheta final mostra só o nome')
elif not os.path.exists(os.path.join(P, lg)): erros.append(f'logo não encontrado: {lg}')
if not (B.get('assinatura') or {}).get('perfis'): avisos.append('assinatura sem perfis (@): a vinheta não vai chamar para seguir')
for f in ('voice.md', 'about-me.md'):
    if not os.path.exists(os.path.join(P, f)): avisos.append(f'{f} ausente: o roteiro e a legenda vão usar uma voz genérica')
for a in avisos: print('AVISO:', a)
if erros:
    for e in erros: print('ERRO:', e)
    sys.exit('Corrija os erros acima e rode de novo.')
# ---- monta a skill decoded-marca ----
D = os.path.join(OUT, 'decoded-marca'); shutil.rmtree(D, ignore_errors=True); os.makedirs(D)
for f in os.listdir(P):
    s = os.path.join(P, f)
    if os.path.isfile(s) and not f.endswith('.zip') and f != 'SKILL.md': shutil.copy(s, D)
    elif os.path.isdir(s) and f in ('fontes', 'referencias'): shutil.copytree(s, os.path.join(D, f))
nome = B.get('nome', 'minha marca')
open(os.path.join(D, 'SKILL.md'), 'w', encoding='utf-8').write(f"""---
name: decoded-marca
description: Identidade da marca {nome} (cores, fontes, logo, voz, público e séries). Use junto com as skills decoded-* sempre que for criar ideia, roteiro, animação, capa ou legenda para {nome}, ou quando a pessoa perguntar sobre a própria marca, voz ou paleta.
---

# Marca · {nome}

Esta skill guarda a identidade de {nome}. As skills do pacote leem os arquivos desta pasta:

- `brand.json`: cores por papel, fontes, logo, séries, assinatura e ritmo da voz.
- `voice.md`: como {nome} fala (tom, ritmo, ganchos, fechamentos, o que nunca faz).
- `about-me.md`: público, pilares, promessa e limites.

Leia `voice.md` e `about-me.md` antes de escrever qualquer texto para esta marca. Não altere estes arquivos durante uma produção: mudanças de marca são feitas pela configuração (skill decoded-estudio), que gera um novo pacote.
""")
z = os.path.join(OUT, 'decoded-marca.zip')
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as Z:
    for root, _, files in os.walk(D):
        for f in files: fp = os.path.join(root, f); Z.write(fp, os.path.relpath(fp, OUT))
print('skill da marca:', z)
# ---- prévia ----
if not A.sem_previa:
    def find(pat):
        r = subprocess.run(f"find / -path '*{pat}' -not -path '/proc/*' 2>/dev/null | head -1", shell=True, capture_output=True, text=True).stdout.strip(); return r
    rj = find('decoded-animacao/scripts/render.js')
    if not rj: print('AVISO: skill decoded-animacao não encontrada; prévia de vídeo pulada.')
    else:
        W = os.path.join(OUT, '_previa_marca'); shutil.rmtree(W, ignore_errors=True); os.makedirs(W)
        serie = (B.get('series') or ['SÉRIE'])[0]
        v = {"tema": "teste de marca", "serie": serie, "duracao": 6, "blocos": [
            {"a": 0, "b": 3, "bg": "fundo", "cy": 900, "linhas": [[["O", "ligacao", 100, "apoio", 0.1], ["teste", "ligacao", 100, "texto", 0.3]], [["DA MARCA", "impacto", 190, "destaque", 0.6, "pop"]], [["em", "ligacao", 90, "apoio", 1.0], ["movimento", "ligacao", 120, "texto", 1.2, "draw"]]], "extras": [{"tipo": "selo", "texto": "CONTRASTE OK", "x": 540, "y": 1380, "at": 1.4, "tamanho": 44}]},
            {"a": 3, "b": 6, "bg": "destaque", "wipe": True, "cy": 900, "linhas": [[["no", "ligacao", 110, "fundo", 3.1]], [["DESTAQUE", "impacto", 200, "fundo", 3.3, "pop"]], [["também", "ligacao", 110, "fundo", 3.7]]]}]}
        json.dump(v, open(os.path.join(W, 'video.json'), 'w'), ensure_ascii=False)
        bj = os.path.join(D, 'brand.json')
        subprocess.run(['node', rj, os.path.join(W, 'video.json'), 'still', '2.6', '5.6', '--out', W, '--marca', bj], check=False)
        sig = subprocess.run(['node', rj, '-', 'assinatura', '--out', os.path.join(W, 'sig.mp4'), '--marca', bj], cwd=W, check=False)
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-ss', '2.9', '-i', os.path.join(W, 'sig.mp4'), '-frames:v', '1', os.path.join(W, 'sig.png')])
        cp = find('decoded-capa/scripts/capa.py'); ca = find('decoded-capa/assets/capa-base.html'); imgs = []
        if cp and ca:
            h = open(ca, encoding='utf-8').read().replace('>SÉRIE<', f'>{serie}<').replace('<div class="bg"></div><div class="fade"></div>', '')
            open(os.path.join(W, 'capa.html'), 'w', encoding='utf-8').write(h)
            subprocess.run(['python3', cp, os.path.join(W, 'capa.html'), os.path.join(W, 'capa.png'), '--marca', bj], check=False)
        from PIL import Image, ImageDraw
        parts = [os.path.join(W, f) for f in ('still_2.6.png', 'still_5.6.png', 'sig.png', 'capa.png') if os.path.exists(os.path.join(W, f))]
        G = Image.new('RGB', (360 * len(parts) + 20 * (len(parts) + 1), 680), (28, 28, 28))
        for i, p in enumerate(parts): G.paste(Image.open(p).convert('RGB').resize((360, 640)), (20 + i * 380, 20))
        pv = os.path.join(OUT, 'previa-marca.png'); G.save(pv); print('prévia:', pv)
        shutil.rmtree(W, ignore_errors=True)
