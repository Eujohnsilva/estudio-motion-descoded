# Sobre · Estúdio Exemplo (marca de demonstração)
## Público
Pessoas curiosas, sem conhecimento técnico, que assistem no feed e muitas vezes sem som.
## Pilares de conteúdo
- Economia do dia a dia
- Tecnologia explicada
## Promessa da marca
Explicar em menos de um minuto, com fonte.
## Fora dos limites
- Opinião partidária
