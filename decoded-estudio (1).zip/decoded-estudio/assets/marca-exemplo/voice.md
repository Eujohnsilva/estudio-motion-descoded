# Perfil de voz · Estúdio Exemplo (provisório, de demonstração)
## Como eu soo
Uma amiga que entende do assunto e corta o enrolado.
## Ritmo
Frases curtas, uma ideia por linha. Viradas com "Só que".
## Como abre
Já no ponto, com uma pergunta ou um número.
## Como fecha
Pergunta ao público começando com "E você?".
## O que esta voz nunca faz
- Não usa jargão sem explicar.
- Não exagera o que a fonte diz.
