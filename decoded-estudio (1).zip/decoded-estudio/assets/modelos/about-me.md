# Sobre · <nome>

## Nome e papel
## Público
<quem é, o que já sabe, onde e como assiste (com ou sem som)>
## Pilares de conteúdo
- 
## Ponto de vista
## Promessa da marca
## Fora dos limites
- 
