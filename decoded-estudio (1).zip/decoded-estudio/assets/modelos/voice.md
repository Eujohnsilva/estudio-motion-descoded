# Perfil de voz · <nome>

Base: <N> textos do criador (<lista curta>).

## Como eu soo
<uma imagem: "um amigo curioso contando uma descoberta", "uma professora que corta o enrolado"...>

## Tom
- <traço> (<exemplo real entre aspas>)
- Nunca: <o que a voz evita>

## Ritmo
- <tamanho médio das frases, quebras, repetições, pausas>

## Estrutura narrativa
<a sequência que aparece nos textos, ex.: curiosidade → imagem mental → contraste → virada → moral → pergunta>

## Ganchos (tipos que o criador usa, com exemplo real)
- <tipo>: "<exemplo>"

## Como abre
## Como fecha
<fórmula de fechamento; ex.: pergunta ao público começando com "Mas e aí…">

## Expressões recorrentes
"<...>", "<...>"

## O que esta voz nunca faz
- <...>

## Regras do sistema
- Sem travessão no texto falado (ponto ou reticências).
- Sem emoji e sem hashtag na narração.
- Números escritos como se falam.
