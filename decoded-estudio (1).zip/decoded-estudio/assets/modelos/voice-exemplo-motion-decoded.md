# Voice Profile

Base: 4 textos do autor (Diabo Veste Prada 2, Matt Taylor/Kevin James, podcast das freiras, ensaio pessoal sobre marketing).

## Como eu soo
Um amigo curioso contando uma descoberta. Começa com algo que intriga, conta a história em passos curtos e, no fim, puxa o fato para um significado maior sobre comportamento, marcas ou a vida. Informal e próximo, mas com raciocínio.

## Tom
- Curioso e intrigado ("o mais curioso", "chamava atenção").
- Conversado, com português falado: "a gente", "gente", "pra", "tá", "E aí…".
- Reflexivo. Quase todo texto termina numa moral.
- Humor leve e irônico: "como se frisbee fosse uma grande conquista da vida".
- Nunca: agressivo, sensacionalista, professoral ou técnico demais.

## Ritmo
- Uma ideia por linha. Frases curtas, raramente acima de 20 palavras.
- Listas faladas em sequência: "Viagem grande. / Conquista grande. / Drama grande."
- Repetição no início das frases: "Pode estudar roteiro. / Pode entender retenção."; "Menos distração. / Menos cobrança."
- Reticências para criar pausa e suspense: "E, de fato...transbordou."
- Viradas começando com "Mas", "Só que", "Porém".

## Estrutura narrativa (usada de forma consciente)
Curiosidade/efeito AHA → linguagem familiar e imagem mental → contraste → conflito e mudança → tema e moral → relevância emocional → fechamento.
Em motion, cada etapa vira uma cena.

## Ganchos
- Descoberta: "Eu encontrei um podcast feito por freiras…"
- Superlativo com cautela: "Essa é, talvez, a estratégia de marketing mais genial que um filme já usou."
- Pergunta direta: "O que podemos esperar desse filme?"
- Dado ou notícia: "Os profissionais de Marketing estão entre as profissões com maior risco de estresse no Brasil."
- Promessa de inclusão: "é uma piada interna que, depois desse vídeo, você também vai fazer parte."

## Como eu abro
Já no ponto curioso, sem apresentação e sem "oi, gente".

## Como eu fecho
Com uma moral curta e uma chamada suave: uma pergunta ("Mas e aí… o que vocês esperam desse filme?"), uma inclusão ("E agora você também faz parte.") ou um convite emocional ("Se você também sente que a vida ficou barulhenta demais, fica por aqui."). Nunca "siga agora" nem "link na bio".

## Expressões recorrentes
"talvez", "curioso", "E o mais curioso", "a gente", "Só que", "Mas e aí…", "no fim", "de fato".

## Fora do padrão (provisório, observado nos 4 textos)
- Nenhuma hashtag ou emoji no roteiro (0 de 4).
- Nenhuma lista numerada nem jargão em inglês, salvo "hook" (1 de 4).
- Travessão aparece em 1 de 4 textos. Regra do sistema: não usar; trocar por ponto ou reticências.
- Caixa alta para ênfase só no ensaio pessoal ("OLHA QUE COISA"). Não usar no Motion Decoded.

## O que esta voz nunca faz
- Não afirma sem cautela: suaviza com "talvez" e "deve" quando é previsão.
- Não fica no fato. Sempre responde "e por que isso importa?".
- Não fala de cima. Explica como quem também acabou de descobrir.
- Não vende segredo nem fórmula mágica (crítica explícita no ensaio).

## Notas de adaptação para o Motion Decoded
- Os roteiros originais têm de 60 a 120 segundos. Para a série "Notícia em 15s", manter só gancho, contraste e moral.
- A promessa da marca é ser confiável: todo dado precisa de fonte checada, mesmo quando o tom é leve.
- O ensaio pessoal serviu para ritmo e tom. O conteúdo pessoal fica fora do perfil (about-me.md).
- Corrigir deslizes de digitação dos rascunhos ("sequência", "seguia", "profissionais").
