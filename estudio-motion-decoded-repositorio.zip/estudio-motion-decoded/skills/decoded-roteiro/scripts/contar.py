# Estima a duração da narração e checa o texto falado.
# Uso: python3 contar.py roteiro.txt [--pps 2.0] [--alvo 30-60]
import sys, re, argparse
ap = argparse.ArgumentParser(); ap.add_argument('arq'); ap.add_argument('--pps', type=float, default=2.0); ap.add_argument('--alvo', default=None); A = ap.parse_args()
T = open(A.arq, encoding='utf-8').read().strip()
lines = [l.strip() for l in T.splitlines() if l.strip()]
words = T.split(); n = len(words); dur = n / A.pps
print(f'{n} palavras · {len(lines)} linhas · duração estimada ≈ {dur:.0f}s (a {A.pps} palavras/s)')
al = []
if A.alvo:
    lo, hi = map(float, A.alvo.split('-'))
    if dur > hi: al.append(f'acima do alvo ({hi:.0f}s): corte cerca de {int((dur - hi) * A.pps)} palavras')
    if dur < lo: al.append(f'abaixo do alvo ({lo:.0f}s)')
for i, l in enumerate(lines, 1):
    w = len(l.split())
    if w > 15: al.append(f'linha {i} com {w} palavras (quebre em duas): "{l[:60]}"')
    if re.search(r'[—–]', l): al.append(f'linha {i}: travessão (troque por ponto ou reticências)')
    if re.search(r'#\w', l): al.append(f'linha {i}: hashtag na narração')
    if re.search(r'[\U0001F300-\U0001FAFF☀-➿]', l): al.append(f'linha {i}: emoji na narração')
    for m in re.findall(r'\b\d[\d.,%]*\b', l): al.append(f'linha {i}: "{m}" em algarismos. Escreva como será falado (a sincronização usa este texto)')
    if re.search(r'\b(link na bio|siga agora|se inscreva)\b', l, re.I): al.append(f'linha {i}: chamada de "siga/link" na narração')
if lines and not re.search(r'\?\s*$', lines[-1]): al.append('a última linha não é uma pergunta (confira a fórmula de fechamento da voz)')
print('\n'.join('ALERTA: ' + a for a in al) if al else 'sem alertas')
