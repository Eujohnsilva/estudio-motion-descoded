# Requisitos do áudio da narração

A geração da voz não faz parte do pacote. O criador grava no celular ou gera numa ferramenta de voz (inclusive com voz clonada própria). Para a animação sincronizar palavra por palavra:

- **Formato:** MP3, WAV ou M4A, 44,1 kHz.
- **Texto exato:** junto com o áudio, o texto **idêntico** ao que foi falado. Se algo mudou na gravação, mande a versão falada.
- **Pausas audíveis** entre frases (0,3 a 0,6 s) e silêncio limpo, sem música de fundo. Uma ideia por linha no texto ajuda a ferramenta de voz a criar essas pausas.
- **Ritmo de referência:** 1,9 a 2,2 palavras por segundo. Na primeira narração real, meça e salve o ritmo em `voz.palavras_por_segundo` da marca.
- **Sem trilha no arquivo.** A música entra depois, no app da rede social: assim o vídeo também aparece na página do áudio em alta.

## Dicas para ferramentas de voz
- Reticências e quebras de linha viram pausas; vírgulas viram pausas curtas.
- Gere frase a frase as partes que saírem com entonação errada e junte; não force correção com pontuação estranha, porque o texto precisa continuar igual ao falado.
- Nomes estrangeiros: mantenha a grafia original no texto; a sincronização tem um dicionário de pronúncia (campo `pronuncia` da marca).
