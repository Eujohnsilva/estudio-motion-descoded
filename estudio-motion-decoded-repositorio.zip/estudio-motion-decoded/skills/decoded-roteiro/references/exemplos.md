# Roteiros reais (Motion Decoded) e o que cada escolha resolve

## Vídeo 5 · Luxo feito à mão x IA (48,7 s, 105 palavras)
```
A Prada contratou um animador da Disney
pra desenhar o Natal à mão.
Em 2026. No auge da IA.

O filme tem atrizes de verdade
no meio de bichos desenhados quadro a quadro.
Quem comandou foi John Pomeroy,
que passou três décadas na Disney.

Parece nostalgia? Não é.
Quando a Valentino lançou um anúncio feito com IA,
os comentários chamaram de barato e preguiçoso.
E a Tod's foi além:
batizou a própria coleção de "inteligência artesanal".

O motivo é simples.
Quando qualquer um gera uma imagem em segundos...
a imagem para de impressionar.
O que impressiona é o tempo que alguém gastou nela.
No luxo, o esforço virou o produto.

Ah, e esse vídeo?
Foi feito com IA.
A diferença é onde fica a mão humana.
Aqui, ela tá no roteiro e na checagem.

Mas e aí... você pagaria mais por algo feito à mão?
```
**Por que funciona:**
- Gancho de contraste temporal ("Em 2026. No auge da IA.") em 3 s.
- "Parece nostalgia? Não é." abre o laço que só fecha em "o esforço virou o produto".
- Dois casos (Valentino, Tod's) e não cinco: o vídeo explica o porquê, não lista.
- Virada final exclusiva do perfil ("esse vídeo foi feito com IA") amarra o tema ao criador.
- Fechamento na fórmula da voz, com pergunta que convida comentário.

**Mapa de cenas:** Prada ao fundo → "2026 / IA" → filme como cartão → foto do animador → "NÃO É." → anúncio da Valentino pixelando → Tod's com as iniciais I/A → imagem gerada por IA perdendo a cor → foto real e "TEMPO" → "O ESFORÇO VIROU O PRODUTO" → "FOI FEITO COM IA" → checks de roteiro e checagem → "feito à mão?".

**Notas de precisão:** os casos de outras marcas citados na referência original ficaram fora por falta de confirmação independente.

## Vídeo 6 · Bastidores (66 s)
Abre com a pergunta que o vídeo responde ("Como a gente cria nossos vídeos em motion…?"), depois passos numerados ("O primeiro passo… Em seguida… Depois… Por fim…"), e fecha com a moral ("a IA faz a produção, mas a decisão do que vale a pena contar continua sendo minha") antes da pergunta. Formato bom para séries de processo.

## Correções que viraram regra
| Antes | Depois | Por quê |
|---|---|---|
| Roteiro de 35 s gravado com 53 s | estimar pela voz real (~2 palavras/s) | a voz clonada fala mais devagar que a leitura |
| "não foi o governo" | "de quem é esse imposto" | processo, não militância |
| "não foi emoção genuína" | piada mantida, afirmação cortada | ninguém sabe o que ele sentiu |
| "o roteiro que vazou" | "o roteiro que ele mostrou" | verbo exato do fato |
| "só com o Claude" | "com o Claude" | outras ferramentas fizeram parte |
