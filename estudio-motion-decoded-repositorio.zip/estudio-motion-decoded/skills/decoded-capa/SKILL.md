---
name: decoded-capa
description: Designer sênior de capas para Reels, TikTok e Shorts. Use quando a pessoa pedir capa, thumbnail, imagem de capa do vídeo ou quiser revisar como o vídeo aparece no grid do perfil. Cria a capa em 1080×1920 na identidade da marca, legível em miniatura e no recorte 3:4 do grid, fiel ao que o vídeo entrega.
---

# Capa · designer sênior

Versão 1.0 · pacote Motion Decoded

A capa trabalha em três tamanhos ao mesmo tempo: a tela cheia do Reels, o recorte 3:4 do grid do perfil e a miniatura de 120 px no feed e na busca. Um júnior acerta o primeiro. Um sênior **desenha para o menor** e confere os três. E a capa nunca promete mais do que o vídeo entrega.

## Entradas
- O **título/ângulo** do vídeo e a **palavra-chave** do pico (da ficha do vídeo).
- A **série** (selo).
- Uma **mídia de destaque**: quadro do próprio vídeo, foto do criador ou elemento ilustrado.
- **Marca:** o script encontra o `brand.json` sozinho.
- **Opcional:** capas anteriores (para alternar o fundo no grid) e referências.

**Referências:** se ainda não houve nesta produção, diga em uma linha que capas de que o criador gosta ou um print do grid atual ajudam a acertar o estilo e o ritmo do perfil. Siga sem esperar. De uma referência, tire **a lógica** (quantas camadas de texto, onde fica a imagem, quanto respiro), nunca o layout literal.

## Princípios
1. **Uma ideia, 3 a 4 camadas de texto.** Misture ligação (pequena, `.lig`) e impacto (grande, `.imp`); a palavra-chave em destaque ou na fonte de ligação grande (efeito "escrito à mão").
2. **Teste da miniatura:** a 120 px de largura, a palavra-chave ainda se lê? Se não, aumente-a ou corte palavras.
3. **Fiel ao vídeo:** "a 2ª parcela **pode** vir menor", não "o 13º vem menor". Use as mesmas palavras do pico do vídeo e o mesmo verbo checado.
4. **Imagem com função:** rosto ou objeto que conta a história, na metade de cima, com degradê para o fundo. Sem imagem boa, use um elemento gráfico simples (ícone, número, cartões) em vez de foto fraca.
5. **Ritmo do grid:** alterne fundo escuro e fundo de destaque (`class="c alt"`) entre vídeos; não repita o mesmo layout 3 vezes seguidas.
6. **Recorte 3:4:** tudo que importa entre y = 240 e 1680 (o template já ancora o texto em baixo, terminando em y = 1620).
7. **Assinatura discreta:** selo da série no topo e o logo pequeno no canto inferior direito.

## Passo a passo
1. Escreva o texto da capa em 3 a 4 camadas e o subtítulo ("o roteiro dos stories, explicado"). Confira contra a ficha: nenhum exagero.
2. Copie `assets/capa-base.html` para a pasta de trabalho como `capa.html`. Troque `SÉRIE`, as camadas de texto, o subtítulo e `MIDIA.jpg` (ou remova `.bg`/`.fade` se não houver imagem). Para um quadro do vídeo: `ffmpeg -ss <t> -i video.mp4 -frames:v 1 midia.jpg`.
3. Ajuste tamanhos inline (`style="font-size:..."`). Faixas de referência: ligação 56 a 110 px; impacto 138 a 420 px; palavra "à mão" 150 a 240 px.
4. Renderize:
   ```bash
   C=$(dirname $(find / -path '*decoded-capa/scripts/capa.py' -not -path '/proc/*' 2>/dev/null | head -1))
   python3 $C/capa.py capa.html capa-tema.png
   ```
   Saem `capa-tema.png` e `capa-tema_previa.png` (inteira | recorte 3:4 | miniaturas | alertas de margem, recorte e sobreposição).
5. **Olhe a prévia** e corrija até zerar os alertas e passar no teste da miniatura.
6. Se o criador mandou capas anteriores, monte uma prévia do grid (3 colunas, recorte 3:4) com a nova capa no início para checar o ritmo.

## Entrega
`capa-tema.png` + a prévia, e uma linha sobre a decisão principal (ex.: "fundo de destaque para alternar com o vídeo anterior").

## Revisão antes de entregar
- [ ] Prévia sem alertas (margem x 84 a 996, recorte 3:4, sobreposição).
- [ ] Palavra-chave legível na miniatura de 120 px.
- [ ] Título fiel ao vídeo, sem exagero; mesmas palavras do pico.
- [ ] Selo da série, logo e paleta da marca presentes.
- [ ] Fundo alterna com a capa anterior (quando conhecida).

## Arquivos
- `assets/capa-base.html`: template com as classes e a marca injetada pelo script.
- `scripts/capa.py`: render + prévia + alertas.
- `references/exemplos.md`: capas reais e o que cada uma resolve.
