# Capas reais (Motion Decoded) e o que cada uma resolve

![capas](img/capas-reais.jpg)

| # | Texto | Recurso | Por que funciona |
|---|---|---|---|
| 1 | "Seu chip vai pedir o seu **rosto.**" | rosto fatiado + moldura de escaneamento + chip | a consequência pessoal vira imagem; "rosto" em destaque é a palavra que fica |
| 2 | "O ICMS vai subir. A conta **é de quem?**" | duas fotos com o mesmo tratamento + selo ICMS no meio | a pergunta do ângulo é o título; o visual mostra os dois lados sem tomar partido |
| 3 | "Por que a 2ª parcela do **13º** pode vir **menor?**" (fundo destaque) | calendário com o dia | fundo invertido para quebrar o grid; "pode vir" mantém a precisão |
| 4 | "o vídeo do Felca é **FAKE?**" | marca-texto "chorar aqui" + foto P&B ao fundo | a citação real (marcada) é a prova visual; pergunta, não acusação |
| 5 | "Em plena era da IA, **a Prada** desenhou *à mão.*" | quadro do filme ao fundo, "à mão" na fonte de ligação grande | o contraste do vídeo inteiro numa frase; a fonte "escrita" reforça o sentido |
| 6 | "como criamos vídeos em **MOTION** com o Claude" | grid de capas inclinado + selo de código | bastidor mostrado pelo próprio resultado |

## Correções que viraram regra
| Erro | Correção |
|---|---|
| Subtítulo cortado no recorte 3:4 | texto ancorado em baixo terminando em y 1620; conferir a prévia sempre |
| Palavra quebrando por trás do título | `white-space:nowrap` e fonte menor |
| "o roteiro que vazou" | "o roteiro dos stories" (fato exato) |
| "só com o Claude" | "com o Claude" |
