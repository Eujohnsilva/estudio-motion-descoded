# Renderiza a capa (HTML -> PNG 1080x1920) com a marca e gera a prévia de conferência.
# Uso: python3 capa.py capa.html capa.png [--marca brand.json]
# Saídas: capa.png e capa_previa.png (capa inteira | recorte 3:4 do grid | miniatura do feed | alertas)
import sys, os, json, subprocess, argparse, re, tempfile
from PIL import Image, ImageDraw, ImageFont
ap = argparse.ArgumentParser(); ap.add_argument('html'); ap.add_argument('saida'); ap.add_argument('--marca', default=None); A = ap.parse_args()
def find_brand():
    for p in [A.marca, 'brand.json', 'marca/brand.json']:
        if p and os.path.exists(p): return os.path.abspath(p)
    r = subprocess.run("find / -path '*decoded-marca/brand.json' -not -path '/proc/*' 2>/dev/null | head -1", shell=True, capture_output=True, text=True).stdout.strip()
    if r: return r
    r = subprocess.run("find /mnt/user-data /mnt/project -name brand.json 2>/dev/null | head -1", shell=True, capture_output=True, text=True).stdout.strip()
    if r: return r
    sys.exit('ERRO: brand.json não encontrado. Rode a configuração de marca (decoded-estudio) ou passe --marca.')
bp = find_brand(); B = json.load(open(bp, encoding='utf-8')); bdir = os.path.dirname(bp)
C = {'fundo': '#0A0A0A', 'texto': '#F2F2EC', 'destaque': '#C8FF2E', 'apoio': '#A9A9A2', 'rotulo': '#7C7C76'}; C.update({k: v for k, v in B.get('cores', {}).items() if isinstance(v, str)})
DEF = {'impacto': ('/usr/share/fonts/opentype/inter/InterDisplay-ExtraBold.otf', 800, False), 'ligacao': ('/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf', 500, True), 'rotulo': ('/usr/share/fonts/opentype/inter/Inter-SemiBold.otf', 600, False)}
css = ''; F = B.get('fontes', {}); fam = {'impacto': 'F_IMP', 'ligacao': 'F_LIG', 'rotulo': 'F_ROT'}; spec = {}
for r, (arq, peso, it) in DEF.items():
    f = F.get(r, {}); a = f.get('arquivo', arq if not f.get('familia') else None); peso = f.get('peso', peso); it = f.get('italico', it); spec[r] = (peso, it)
    src = f'url("file://{a if a.startswith("/") else os.path.join(bdir, a)}")' if a else f'local("{f["familia"]}")'
    css += f'@font-face{{font-family:{fam[r]};src:{src};font-weight:{peso};font-style:{"italic" if it else "normal"}}}\n'
css += ':root{' + ''.join(f'--{k}:{v};' for k, v in C.items()) + f'--imp-peso:{spec["impacto"][0]};--lig-peso:{spec["ligacao"][0]};--lig-estilo:{"italic" if spec["ligacao"][1] else "normal"}}}'
logo = B.get('logo', {}).get('arquivo'); logo = ('file://' + (logo if logo.startswith('/') else os.path.join(bdir, logo))) if logo else ''
html = open(A.html, encoding='utf-8').read().replace('/*{{MARCA}}*/', css).replace('src="LOGO"', f'src="{logo}"')
hdir = os.path.dirname(os.path.abspath(A.html)); tmp = os.path.join(hdir, '.capa_render.html'); open(tmp, 'w', encoding='utf-8').write(html)
js = f"""let PW;try{{PW=require('playwright')}}catch(e){{for(const r of [require('child_process').execSync('npm root -g').toString().trim(),'/usr/local/lib/node_modules_global','/opt/npm-tools/node_modules']){{try{{PW=require(r+'/playwright');break}}catch(_){{}}}}}}const {{chromium}}=PW;(async()=>{{const b=await chromium.launch({{args:['--allow-file-access-from-files']}});const p=await b.newPage({{viewport:{{width:1080,height:1920}}}});
await p.goto('file://{tmp}');await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(250);
const r=await p.evaluate(()=>{{const out=[];for(const el of document.querySelectorAll('.c *')){{if(!el.childElementCount&&el.textContent.trim()){{const q=el.getBoundingClientRect();out.push([el.textContent.trim().slice(0,40),Math.round(q.left),Math.round(q.top),Math.round(q.right),Math.round(q.bottom),getComputedStyle(el).color]);}}}}return out;}});
console.log(JSON.stringify(r));await p.screenshot({{path:'{os.path.abspath(A.saida)}',clip:{{x:0,y:0,width:1080,height:1920}}}});await b.close();}})();"""
res = subprocess.run(['node', '-e', js], capture_output=True, text=True, cwd=os.path.dirname(os.path.abspath(__file__)))
os.remove(tmp)
if res.returncode: sys.exit(res.stderr)
boxes = json.loads(res.stdout.strip().splitlines()[-1])
alerts = []
for t, x0, y0, x1, y1, c in boxes:
    if x0 < 84 or x1 > 996: alerts.append(f'"{t}" sai da margem lateral (x {x0}–{x1})')
    if y0 < 240 or y1 > 1680: alerts.append(f'"{t}" fica fora do recorte 3:4 do grid (y {y0}–{y1})')
for i in range(len(boxes)):
    for j in range(i + 1, len(boxes)):
        a, b = boxes[i], boxes[j]
        ix = min(a[3], b[3]) - max(a[1], b[1]); iy = min(a[4], b[4]) - max(a[2], b[2])
        if ix > 6 and iy > 14: alerts.append(f'"{a[0]}" encosta/sobrepõe "{b[0]}"')
im = Image.open(A.saida).convert('RGB'); W = 360; H = 640
full = im.resize((W, H)); crop = im.crop((0, 240, 1080, 1680)).resize((W, 480)); tiny = im.crop((0, 240, 1080, 1680)).resize((120, 160))
P = Image.new('RGB', (W * 3 + 80, H + 140), (28, 28, 28)); d = ImageDraw.Draw(P)
try: Fn = ImageFont.truetype('/usr/share/fonts/opentype/inter/Inter-SemiBold.otf', 20)
except Exception: Fn = ImageFont.load_default()
P.paste(full, (20, 40)); P.paste(crop, (W + 40, 40)); P.paste(tiny, (2 * W + 60, 40)); P.paste(tiny.resize((90, 120)), (2 * W + 200, 40))
d.text((20, 10), 'capa inteira (Reels)', fill=(220, 220, 220), font=Fn); d.text((W + 40, 10), 'recorte 3:4 (grid do perfil)', fill=(220, 220, 220), font=Fn); d.text((2 * W + 60, 10), 'miniaturas (feed/busca)', fill=(220, 220, 220), font=Fn)
y = H + 50
for a in (alerts or ['sem alertas de margem ou recorte'])[:4]: d.text((20, y), ('⚠ ' if alerts else '✓ ') + a, fill=(255, 120, 120) if alerts else (160, 230, 120), font=Fn); y += 24
pv = re.sub(r'\.png$', '', A.saida) + '_previa.png'; P.save(pv)
print('ok', A.saida, '·', 'prévia:', pv); [print('ALERTA:', a) for a in alerts]
