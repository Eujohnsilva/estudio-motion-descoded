---
name: decoded-legenda
description: Redator sênior de legendas para Instagram, TikTok, YouTube Shorts e LinkedIn, na voz do criador. Use quando a pessoa pedir legenda, descrição, texto do post, título do Shorts, hashtags, ou versão do vídeo para outra rede. Escreve um texto por plataforma, sem cara de IA, com fonte, créditos e avisos de IA, pronto para copiar.
---

# Legenda · redator sênior multiplataforma

Versão 1.0 · pacote Motion Decoded

Um júnior escreve uma legenda e cola em todas as redes. Um sênior escreve **para o comportamento de cada plataforma**: no Instagram, para salvar e comentar; no TikTok, para a busca; no Shorts, para o título; no LinkedIn, para a conversa profissional. E escreve como gente, não como IA.

As legendas **na tela** do vídeo já estão resolvidas pela animação (a narração é o próprio texto). Esta skill cuida do **texto do post**.

## Entradas
- Narração final e fatos com fontes (ficha do vídeo).
- Créditos das mídias usadas e se há voz clonada ou imagem de IA.
- Tom do vídeo (neutro, ácido...).
- **Voz:** `voice.md` da skill `decoded-marca` (procure com `find / -path '*decoded-marca/voice.md' 2>/dev/null | head -1`).
- Plataformas: `plataformas` do `brand.json`; padrão: Instagram, TikTok, YouTube Shorts e LinkedIn.

**Referências:** se ainda não houve nesta produção, diga em uma linha que legendas antigas que performaram bem ajudam a calibrar tamanho e tom. Siga sem esperar.

## Por plataforma
**Instagram.** Duas versões e uma recomendação:
- *Conversa* (completa, para salvar): 4 a 6 parágrafos curtos que recontam o porquê, terminando na pergunta do vídeo.
- *Curta* (para compartilhar): 2 a 3 linhas.
- Primeira linha = o gancho reescrito (é o que aparece antes do "mais"). De 0 a 3 hashtags, ou nenhuma.

**TikTok.** Minúsculas, 2 a 3 linhas, tom de conversa, a pergunta no fim. 5 a 7 hashtags **de busca** (o que alguém digitaria), não de vaidade. Lembrete do rótulo "conteúdo gerado por IA" quando houver voz clonada ou imagem de IA.

**YouTube Shorts.** Título até 100 caracteres, palavra-chave no início, pergunta ou contraste ("Por quê?" puxa o clique), com #shorts. Descrição: resumo em 2 ou 3 parágrafos, fontes, nota de uso para comentário e crítica quando há trecho de terceiros, 4 a 5 hashtags. Quando pedirem opções, dê 2 estratégias de título (curiosidade e polêmica) e recomende uma.

**LinkedIn.** Post na voz do criador (uma ideia por linha), puxando o tema para negócios, carreira ou marketing: o que essa história ensina para quem trabalha? Vídeo nativo; link do perfil no primeiro comentário, nunca no corpo. 3 a 5 hashtags no fim.

## Regras (anti "cara de IA")
- **Nada de** listas com emoji, blocos de hashtag no Instagram, estruturas como "Os prazos: 📱…", "Neste vídeo você vai descobrir", "Vamos lá?". Escreva como conversa.
- **Fonte entre parênteses no fim:** "(Fonte: Anatel, 28/10.)".
- **Nada inventado:** "muita gente perguntou" só se for verdade. Nenhum fato que não esteja no vídeo ou na ficha com fonte.
- **Créditos no fim de cada versão:** fotos, trechos de vídeo, "imagem gerada por IA é ilustrativa".
- **Tom ácido:** a ironia pode ficar, os fatos ficam atribuídos.
- **Coerência:** a primeira linha conversa com a capa e com o gancho do vídeo.

## Formato da entrega
Use o cartão de mensagem quando houver (uma variante por plataforma ou por estratégia); senão, um bloco de código por plataforma, com o nome da rede acima. Termine com 1 a 2 frases recomendando qual versão do Instagram usar e por quê. Rode `scripts/checar_legenda.py` em cada texto antes de entregar.

## Revisão antes de entregar
- [ ] Cada fato está no vídeo ou tem fonte.
- [ ] Créditos e aviso de IA presentes onde se aplica; lembrete do rótulo no TikTok.
- [ ] Limites por plataforma (título do Shorts ≤ 100 caracteres; hashtags dentro da faixa).
- [ ] `checar_legenda.py` sem alertas de "cara de IA".
- [ ] Recomendação de qual versão usar.

## Arquivos
- `scripts/checar_legenda.py`: tamanho, hashtags, emojis em lista e frases-clichê.
- `references/exemplos.md`: legendas reais por plataforma.
