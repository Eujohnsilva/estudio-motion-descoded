# Legendas reais · vídeo 5 (Luxo feito à mão x IA)
**Instagram (Conversa):**
```
Em plena era da IA, a Prada chamou um animador que passou três décadas na Disney pra desenhar o filme de Natal à mão.

E não é nostalgia. Quando a Valentino lançou um anúncio feito com IA, os comentários chamaram de barato e preguiçoso. A Tod's foi além e batizou a coleção de "inteligência artesanal".

Quando qualquer um gera uma imagem em segundos, o que impressiona passa a ser o tempo que alguém gastou nela. No luxo, o esforço virou o produto.

E sim, esse vídeo foi feito com IA. A mão humana aqui tá no roteiro e na checagem.

Você pagaria mais por algo feito à mão?

Créditos: filme "Drawing Prada" (Prada, 2026), anúncio da Valentino (2025), foto de John Pomeroy. Imagem da Coca-Cola com a tag "gerada por IA" é ilustrativa, não é campanha oficial.
```
**TikTok:**
```
a prada desenhou o natal à mão em pleno 2026 e o motivo diz muito sobre a IA ✍️

(e sim, esse vídeo foi feito com IA, assiste até o fim)

você pagaria mais por algo feito à mão?

#prada #luxo #ia #inteligenciaartificial #marketing #publicidade #fyp
```
**YouTube Shorts:**
```
TÍTULO:
A Prada desenhou o Natal à mão. Em 2026. Por quê? #shorts

DESCRIÇÃO:
Em plena era da IA, a Prada chamou John Pomeroy, que passou três décadas como animador na Disney, pra desenhar à mão o filme de Natal "Drawing Prada".

Não é nostalgia: quando a Valentino lançou um anúncio feito com IA, foi chamada de barata e preguiçosa. E a Tod's batizou a própria coleção de "inteligência artesanal".

Quando gerar imagem leva segundos, o que impressiona é o tempo que alguém gastou. No luxo, o esforço virou o produto.

E esse vídeo? Feito com IA, com roteiro e checagem humanos.

Você pagaria mais por algo feito à mão? Comenta 👇

Fontes: Variety, eWeek, Grazia. Trechos e imagens usados para comentário e crítica. A imagem da Coca-Cola marcada "gerada por IA" é ilustrativa, não é campanha oficial.

#prada #luxo #ia #marketing #shorts
```
**LinkedIn (Reflexão):**
```
A Prada desenhou o filme de Natal à mão.
Em 2026. No auge da IA.

Quem comandou foi John Pomeroy, que passou três décadas como animador na Disney.

Parece nostalgia. Mas talvez seja estratégia.

Quando a Valentino lançou um anúncio feito com IA, os comentários chamaram de barato e preguiçoso.
A Tod's foi além e batizou a própria coleção de "inteligência artesanal".

O raciocínio é simples:
quando qualquer um gera uma imagem em segundos, a imagem para de impressionar.
O que impressiona é o tempo que alguém gastou nela.

No luxo, o esforço virou o produto.

E o mais curioso: o vídeo que eu fiz sobre isso foi produzido com IA.
Só que a mão humana está no roteiro e na checagem de cada informação.

Talvez a pergunta certa não seja "usar ou não usar IA".
Seja onde a sua marca coloca o trabalho humano.

Você pagaria mais por algo feito à mão?

#Marketing #Branding #InteligenciaArtificial #Luxo
```

## Correções que viraram regra
| Erro | Correção |
|---|---|
| Legenda com lista de emojis e bloco de hashtags | reescrever como conversa, fonte entre parênteses. O criador aprovou: "assim fica muito melhor" |
| "Muita gente perguntou" sem ter acontecido | "Hoje a gente abre o processo." |
| Título do Shorts pedido duas vezes | entregar 2 estratégias (curiosidade e polêmica) e recomendar uma |
| Esquecer o rótulo de IA no TikTok | incluir sempre o lembrete |
