# Checa uma legenda antes de entregar.
# Uso: python3 checar_legenda.py arquivo.txt --rede instagram|tiktok|shorts|linkedin
import re, sys, argparse
ap = argparse.ArgumentParser(); ap.add_argument('arq'); ap.add_argument('--rede', required=True); A = ap.parse_args()
T = open(A.arq, encoding='utf-8').read().strip(); L = T.splitlines(); al = []
tags = re.findall(r'#\w+', T); faixa = {'instagram': (0, 3), 'tiktok': (5, 7), 'shorts': (4, 6), 'linkedin': (3, 5)}[A.rede]
if not faixa[0] <= len(tags) <= faixa[1]: al.append(f'{len(tags)} hashtags (faixa para {A.rede}: {faixa[0]} a {faixa[1]})')
emo = r'[\U0001F300-\U0001FAFF☀-➿]'
if sum(1 for l in L if re.match(r'\s*' + emo, l)) >= 2: al.append('linhas começando com emoji (lista com cara de IA)')
if sum(1 for l in L if re.match(r'\s*[-•▪✅✔]\s', l)) >= 3: al.append('lista com marcadores: reescreva como conversa')
for c in ['neste vídeo você vai', 'vamos lá', 'confira', 'não perca', 'você sabia que', 'fique até o final', 'muita gente perguntou', 'mergulhar', 'desvendar']:
    if c in T.lower(): al.append(f'clichê: "{c}"')
if A.rede == 'instagram' and L and len(L[-1].split()) > 0 and re.fullmatch(r'(\s*#\w+)+\s*', L[-1]) and len(tags) > 3: al.append('bloco de hashtags no fim')
if A.rede == 'tiktok' and T != T.lower() and re.search(r'[A-ZÁÉÍÓÚ]{2,}', T) is None and any(c.isupper() for c in T.split('#')[0]): al.append('TikTok: use minúsculas')
if A.rede == 'shorts':
    m = re.search(r'T[IÍ]TULO:\s*\n?(.+)', T)
    if m and len(m.group(1).strip()) > 100: al.append(f'título com {len(m.group(1).strip())} caracteres (máx. 100)')
    if '#shorts' not in T.lower(): al.append('falta #shorts')
if A.rede == 'linkedin' and re.search(r'https?://', T): al.append('link no corpo do post (vai no primeiro comentário)')
if not re.search(r'\?', T): al.append('sem pergunta ao público')
print(f'{A.rede}: {len(T)} caracteres · {len(tags)} hashtags'); print('\n'.join('ALERTA: ' + a for a in al) if al else 'sem alertas')
