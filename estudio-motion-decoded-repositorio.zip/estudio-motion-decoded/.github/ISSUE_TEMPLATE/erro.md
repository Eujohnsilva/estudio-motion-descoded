---
name: Relatar um erro
about: Algo não funcionou como deveria
labels: erro
---
**Qual skill?** (estúdio, ideia, roteiro, animação, capa, legenda)

**O que você pediu?**

**O que esperava?**

**O que aconteceu?** (cole a mensagem de erro, se houver)

**Plano do Claude:** (Pro, Max, Team, Enterprise)
