---
name: Sugerir melhoria
about: Uma ideia para a próxima versão
labels: sugestão
---
**O que você gostaria que o estúdio fizesse?**

**Por que isso ajudaria nos seus vídeos?**

**Tem referência?** (link ou print)
