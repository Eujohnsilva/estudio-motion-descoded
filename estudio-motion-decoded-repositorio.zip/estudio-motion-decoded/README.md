# Estúdio Motion Decoded

**Seu estúdio de vídeos explicativos em motion, dentro da sua conta do Claude. Sem editor de vídeo.**

![Estúdio Motion Decoded](docs/img/capa.jpg)

Seis skills que trabalham juntas para produzir vídeos verticais para Reels, TikTok e Shorts. É o mesmo processo usado no perfil [@motiondescoded](https://instagram.com/motiondescoded), aberto para qualquer criador.

| Skill | O que faz |
|---|---|
| `decoded-estudio` | Diretor de produção: conduz as etapas em ordem, pede sua aprovação e configura a sua marca na primeira vez |
| `decoded-ideia` | Pesquisa o tema, checa os fatos em duas fontes e escreve o gancho |
| `decoded-roteiro` | Escreve a narração na sua voz, com duração estimada e mapa de cenas |
| `decoded-animacao` | Tipografia cinética sincronizada palavra por palavra com a sua narração; entrega o MP4 1080×1920 |
| `decoded-capa` | Capa legível na miniatura e no recorte 3:4 do grid |
| `decoded-legenda` | Um texto para cada rede (Instagram, TikTok, Shorts, LinkedIn), sem cara de IA |

## Os vídeos saem com a **sua** marca
Na primeira conversa, o estúdio pergunta sobre o seu público, aprende o seu jeito de escrever, define cores, fontes e logo, e gera uma skill pessoal da sua marca. A partir daí, todo vídeo usa a sua identidade.

![Prévia de marca](docs/img/previa-marca.jpg)

Sem logo? Ele gera opções de monograma com as suas iniciais e cores:

![Monogramas](docs/img/monogramas.jpg)

## O que você precisa
- Plano pago do Claude (Pro, Max, Team ou Enterprise) com **Execução de código e criação de arquivos** ativada (Configurações → Recursos).
- A narração é sua: grave no celular ou use a ferramenta de voz que preferir.

## Instalação (5 minutos)
1. Vá em [**Releases**](../../releases/latest) e baixe os 6 arquivos `.zip`.
2. No Claude, abra Configurações → Recursos (ou Personalizar → Skills) e clique em **Enviar skill**.
3. Envie os 6 arquivos **do jeito que vieram, ainda compactados**, um de cada vez. Se o seu computador descompactou algum sozinho, baixe de novo.
4. Abra uma conversa nova e escreva: **"Quero configurar minha marca no estúdio."**
5. No fim da configuração, você recebe `decoded-marca.zip`. Envie também. Pronto.

## Como usar
- Vídeo completo: **"Vamos produzir um vídeo."**
- Etapa avulsa: "me dá uma ideia de vídeo para hoje", "escreve o roteiro sobre X", "anima esta narração" (anexe o áudio e o texto exato), "faz a capa", "escreve as legendas".

Para resultados melhores, mande referências: um vídeo cujo ritmo você admira, uma capa de que gosta, um roteiro seu que performou bem.

## Próxima versão
Estamos preparando uma versão completa com banco de referências de animação, novas habilidades de edição e banco de músicas licenciadas.
**[Entre na lista de espera →](LINK_DA_LISTA_DE_ESPERA)**

## Fez um vídeo com o estúdio?
Marque [@motiondescoded](https://instagram.com/motiondescoded). A gente adora ver.

## Problemas e sugestões
Abra uma [issue](../../issues/new/choose). Conte o que pediu, o que esperava e o que aconteceu.

---
Licença MIT. Projeto independente, sem afiliação com a Anthropic. Claude é marca da Anthropic.
