# Histórico de versões

## 1.0.1 · 2026-11-08
- Primeira versão pública.
- Configuração de marca pede referências antes de desenhar o logo e gera 6 opções de monograma com as iniciais, cores e fontes do criador.
- Regra de originalidade: a identidade de quem usa nunca deriva da marca Motion Decoded.

## 1.0.0
- Seis skills: estúdio, ideia, roteiro, animação, capa e legenda.
- Motor de tipografia cinética parametrizado por marca, alinhamento de narração, efeitos sonoros sintetizados, vinheta da marca, revisão automática de layout.
