# Pesquisa semanal (pauta)

Rode no começo da semana. Entrega: um arquivo `pauta-AAAA-MM-DD.md` com três seções.

## 1. Radar da semana (15 a 20 temas)
Tabela com: #, tema, fontes, link (com data), sinais de atenção (quantos veículos, em quantos dias), o que está acontecendo (2 frases), por que importa para a marca, ângulo para vídeo.

Método:
- Varra cada pilar da marca com 2 a 3 buscas diferentes. Para ciência, busque o estudo original, não só a matéria.
- Registre a data de cada item. Fora de 7 dias: marque como "fora da janela" e mova para atemporal ou evento.
- Ao final, escreva a **nota de cobertura**: onde você procurou, o que não conseguiu varrer (ex.: redes sociais sem acesso) e quantos itens faltaram para a meta. Honestidade sobre a pesquisa é parte do padrão.

## 2. Matriz atemporal (pilares × 8 formatos)
Formatos: prático, inspirador, analítico, contra o senso comum, observação, X vs Y, hoje vs futuro, lista. Uma ideia por célula. Marque **a ideia mais forte** e diga por quê em 2 frases (conexão com a marca + potencial visual).

## 3. Ganchos do tema principal
6 ganchos de tipos diferentes (veja `ganchos.md`), cada um em 2 linhas de até 40 caracteres.

## Exemplo de linha do radar (real)
| 1 | Anatel vai exigir reconhecimento facial para ter chip | InvestNews, Metrópoles | [InvestNews 28/10](link) | 4+ veículos em 3 dias | Novas linhas pré-pagas exigem biometria a partir de 30/09/2027; linhas antigas validam até 31/12/2028 | Afeta qualquer pessoa com celular e tem um porquê claro (fraude) | "Seu chip vai pedir seu rosto. E tem um motivo." |
