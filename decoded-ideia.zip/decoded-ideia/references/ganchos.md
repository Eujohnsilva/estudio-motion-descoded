# Ganchos

O gancho aparece **escrito na tela nos 2 primeiros segundos** e é a primeira frase falada. Ele decide se a pessoa fica. Formato: 2 linhas de até 40 caracteres, afirmação + virada.

| Tipo | Quando usar | Exemplo real |
|---|---|---|
| Pergunta direta | o ângulo já é uma pergunta do público | "Os dinossauros morreram. Os crocodilos, não. Por quê?" |
| Consequência pessoal | regra nova que afeta a pessoa | "Tem chip no seu CPF que não é seu? / A Anatel quer acabar com isso." |
| Contraste temporal | algo "fora de época" | "A Prada desenhou o Natal à mão. / Em 2026." |
| Dado forte | número que surpreende sozinho | "O planeta aquece quase o dobro / do que aquecia há 30 anos." |
| Correção de crença | mito que todo mundo repete | "Estrela cadente não pega fogo. / Ela explode." |
| Descoberta | bastidor, coisa pouco conhecida | "Como a gente cria vídeos em motion / sem editor de vídeo?" |
| Superlativo com cautela | quando a voz da marca permite | "Talvez a jogada de marketing / mais genial do ano." |

## Armadilhas
- **Promessa maior que o fato:** "o 13º vem menor" quando o certo é "a 2ª parcela pode vir menor". O gancho herda a precisão da checagem.
- **Clickbait de identidade:** "você está fazendo errado" sem mostrar o erro no vídeo.
- **Gancho que exige contexto:** se a pessoa precisa saber quem é X para entender, troque X pelo papel ("um animador da Disney").
- **Pergunta que se responde com "não":** prefira perguntas abertas (por quê, como, de quem).
- **Mais de 2 linhas:** se não cabe, o ângulo ainda está largo.

## Teste rápido
Leia o gancho em voz alta sem o resto do vídeo. Se dá para entender **o que** está em jogo e **por que** importa para quem ouve, passou.
