# Erros reais e correções

| Erro | Correção |
|---|---|
| Sugerir tema de eleição sem saber o resultado | Consultar a fonte oficial de resultados antes. Não citar placar com apuração aberta |
| Aceitar a premissa do criador ("o gesto X decidiu a eleição") | Separar o fato (o gesto se espalhou, foi citado) da causalidade sem prova |
| Aceitar "o estado aumentou o imposto" quando a decisão é nacional | Mostrar o processo: quem decide, onde vale |
| Levar para o roteiro um fato da referência que não se confirma | Retirar e avisar o criador do que foi cortado e por quê |
| Usar item de 8 dias como notícia | Marcar como fora da janela; usar como atemporal |
| Dia sem tema forte | Plano B com prazo (evento de amanhã) ou banco da matriz atemporal |
| Lista de casos copiada de um carrossel | Trocar a lista pelo porquê ("quando a imagem fica barata, o esforço vira o produto") |
